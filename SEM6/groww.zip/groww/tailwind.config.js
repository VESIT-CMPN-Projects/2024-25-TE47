module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "#E6F7F2",
          100: "#10362D",
          200: "#99DDCB",
          300: "#66CBB2",
          400: "#33BA98",
          500: "#0ABB92",
          600: "#099F78",
          700: "#07845E",
          800: "#056944",
          900: "#034E2A",
        },
        cardColor: "#1b1b1b",
        danger: "#d55438",
        black: "#121212",
        borderColor: "#2e2e2e",
        backgroundInputColor: "#10362d",
        purple: {
          100: "#181a2a",
          500: "#98a4ff"
        }
      },
    },
  },
  plugins: [],
};
