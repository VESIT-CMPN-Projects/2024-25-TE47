import { getSessionData } from "./authService";

export async function createWatchlist(watchlist) {
    const browserData = getSessionData();

    const res = await fetch(`${process.env.REACT_APP_API_URL}/watchlists`,{
        method: "POST",
        headers: {
            'Content-type': 'application/json',
            Authorization: `Bearer ${browserData.token}`,
        },
        body: JSON.stringify(watchlist)
    });

    if(!res.ok) {
        console.log(res.status);
        console.log(res.statusText);
    }

    const dataResponse = await res.json();
    return dataResponse;
}

export async function updateWatchlist(watchlistObj,watchlistId) {
    const browserData = getSessionData();

    const res = await fetch(`${process.env.REACT_APP_API_URL}/watchlists/${watchlistId}`, {
        method: "PUT",
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${browserData.token}`,
        },
        body: JSON.stringify(watchlistObj)
    });

    if(!res.ok) {
        console.log(res.status);
        console.log(res.statusText);
    }

    const data = await res.json();
    return data;
}