import { getSessionData } from "./authService";

export async function createPorfolio(user) {
    const browserData = getSessionData();

      const portfolioDetails = {
        user_id: user.user.id,
        user: user.user,
        balance: 0,
      };

      const res = await fetch(
        `${process.env.REACT_APP_API_URL}/portfolio`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${browserData.token}`,
          },
          body: JSON.stringify(portfolioDetails),
        }
      );

      if(!res.ok) {
        throw { message: res.statusText, error: res.status};
      } else {
        await createHolding(user);
      }
}

async function createHolding(user) {
  const browserData = getSessionData();

      const holdingDetails = {
        holdings: [],
        user_id: user.user.id
      };

      const res = await fetch(
        `${process.env.REACT_APP_API_URL}/660/holdings`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${browserData.token}`,
          },
          body: JSON.stringify(holdingDetails),
        }
      );

      if(!res.ok) {
        throw { message: res.statusText, error: res.status};
      }
}

export async function addMoneyToAccount(amount,portfolio) {
    const browserData = getSessionData();
    const addMoney = {
        ...portfolio,
        balance: amount
    }

    const res = await fetch(`${process.env.REACT_APP_API_URL}/660/portfolio`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${browserData.token}`,
        },
        body: JSON.stringify(addMoney)
    });

    if(!res.ok) {
        throw { message: res.statusText, status: res.status };
    }

    const data = await res.json();
    return data;
}