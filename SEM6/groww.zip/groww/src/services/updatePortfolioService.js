import { getSessionData } from "./authService";

export async function createOrder(orderDetail,user) {
    const browserData = getSessionData();
    const order = {
        stockDetail: orderDetail.stockDetail,
        quantity: orderDetail.quantity,
        orderAt: orderDetail.limitOrMarket,
        orderType: orderDetail.orderType,
        orderPrice: orderDetail.orderPrice,
        averagePrice: orderDetail.averagePrice,
        orderValue: orderDetail.orderValue,
        orderTime: orderDetail.orderTime,
        user,
        user_id: user.id
    };

    const res = await fetch(`${process.env.REACT_APP_API_URL}/orders`,{
        method: "POST",
        headers: {
            'Content-type': 'application/json',
            Authorization: `Bearer ${browserData.token}`,
        },
        body: JSON.stringify(order)
    });

    if(!res.ok) {
        console.log(res.status);
        console.log(res.statusText);
    }

    const dataResponse = await res.json();
    return dataResponse;
}

export async function addToHolding(holdingObj) {
    const browserData = getSessionData();
    console.log(holdingObj);

    const res = await fetch(`${process.env.REACT_APP_API_URL}/holdings/${browserData.userId}`, {
        method: "PUT",
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${browserData.token}`,
        },
        body: JSON.stringify(holdingObj)
    });

    console.log(res);

    if(!res.ok) {
        console.log(res.status);
        console.log(res.statusText);
    }

    const data = await res.json();
    return data;
}

export async function updatePortfolio(portfolio) {
    const browserData = getSessionData();

    const res = await fetch(`${process.env.REACT_APP_API_URL}/portfolio/${portfolio.id}`,{
        method: "PUT",
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${browserData.token}`,
          },
        body: JSON.stringify(portfolio)
    });

    if(!res.ok) {
        console.log(res.status);
        console.log(res.statusText);
    }

    const data = await res.json();
    return data;
}