import React from "react";
import { Route, Routes } from "react-router-dom";
import { HomePage, Investments, Login, OrdersPage, Register, SipCalculator, StockDetailsPage, Wallet } from "../pages";

export const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<HomePage />}/>
      <Route path="/investments" element={<Investments />} />
      <Route path="/wallet" element={<Wallet />}/>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/stock/:ticker" element={<StockDetailsPage />}/>
      <Route path="/sip-calculator" element={<SipCalculator />} />
      <Route path="/orders" element={<OrdersPage />} />
    </Routes>
  );
};
