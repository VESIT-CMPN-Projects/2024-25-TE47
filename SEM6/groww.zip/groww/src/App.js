import { AppRoutes } from "./routes";
import { Header } from "./Components";
import { getSessionData, isLoggedIn } from "./services/authService";
import { useDispatch } from "react-redux";
import { useFetch } from "./hooks/useFetch";
import { setUserHoldings, setUserPortfolio } from "./store/portfolioSlice";
import { useEffect } from "react";
import { setWatchlists } from "./store/watchlistSlice";

function App() {
  const browserData = getSessionData();
  const dispatch = useDispatch();
  const {setUrl:portfolioUrl} = useFetch("",data => dispatch(
    setUserPortfolio({
      userPortfolio: data[0]
    })
  ));
  const {setUrl:holdingsUrl} = useFetch("",data => dispatch(
    setUserHoldings({
      userHoldings: data[0]?.holdings
    })
  ));

  const {setUrl:watchlistsUrl} = useFetch("",data => dispatch(
    setWatchlists({
      watchlists: data
    })
  ));
  
  useEffect(() => {
    if(isLoggedIn()) {
      portfolioUrl(`${process.env.REACT_APP_API_URL}/portfolio?user_id=${browserData.userId}`);
      holdingsUrl(`${process.env.REACT_APP_API_URL}/holdings?user_id=${browserData.userId}`);
      watchlistsUrl(`${process.env.REACT_APP_API_URL}/watchlists?user_id=${browserData.userId}`);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[])
  return (
    <div className="bg-black">
      <Header />
      <AppRoutes />
    </div>
  );
}

export default App;
