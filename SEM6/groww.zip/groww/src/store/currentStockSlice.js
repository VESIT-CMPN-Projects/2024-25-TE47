import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    currentStock: null
}

export const currentStockSlice = createSlice({
    name: 'currentStock',
    initialState,
    reducers: {
        setCurrentStock: function(state,action) {
            return {
                ...state,
                currentStock: action.payload.currentStock
            }
        }
    }
});

export const { setCurrentStock } = currentStockSlice.actions;

const currentStockReducer = currentStockSlice.reducer;
export default currentStockReducer;