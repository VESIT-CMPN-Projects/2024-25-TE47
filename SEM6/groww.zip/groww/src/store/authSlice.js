import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    loggedInUserData: null
};

export const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers : {
        setLoggedInUserData: function(state,action) {
            return {
                ...state,
                loggedInUserData: action.payload.loggedInUserData
            }
        }
    }
});

export const { setLoggedInUserData } = authSlice.actions;

const authReducer = createSlice.reducer;
export default authReducer;