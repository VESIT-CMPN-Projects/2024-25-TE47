import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    userPortfolio: null,
    userHoldings: []
};

export const portfolioSlice = createSlice({
    name: 'portfolio',
    initialState,
    reducers: {
        setUserPortfolio: function(state,action) {
            return {
                ...state,
                userPortfolio: action.payload.userPortfolio
            }
        },
        setUserHoldings: function(state,action) {
            return {
                ...state,
                userHoldings: action.payload.userHoldings
            }
        }
    }
});

export const { setUserPortfolio, setUserHoldings } = portfolioSlice.actions;

const portfolioReducer = portfolioSlice.reducer;
export default portfolioReducer;