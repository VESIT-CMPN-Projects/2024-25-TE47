import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    watchlists: []
}

export const watchlistSlice = createSlice({
    name: 'watchlist',
    initialState,
    reducers: {
        setWatchlists: function(state, action) {
            return {
                ...state,
                watchlists: action.payload.watchlists
            }
        },
        addWatchlist: function(state, action) {
            return {
                ...state,
                watchlists: state.watchlists.concat(action.payload.watchlist)
            }
        }
    }
});

export const { setWatchlists, addWatchlist } = watchlistSlice.actions;

const watchlistReducer = watchlistSlice.reducer;
export default watchlistReducer;