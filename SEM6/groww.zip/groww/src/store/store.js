// import authReducer from "./authSlice";
import { configureStore } from '@reduxjs/toolkit';
import portfolioReducer from "./portfolioSlice";
import currentStockReducer from './currentStockSlice';
import watchlistReducer from './watchlistSlice';
import ordersReducer from './ordersSlice';

export default configureStore({
    reducer: {
        // auth: authReducer
        portfolio: portfolioReducer,
        currentStock: currentStockReducer,
        watchlist: watchlistReducer,
        orders: ordersReducer
    }
});