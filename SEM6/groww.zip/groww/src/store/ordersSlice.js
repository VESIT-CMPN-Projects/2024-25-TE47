import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    orders: []
}

export const ordersSlice = createSlice({
    name: 'orders',
    initialState,
    reducers: {
        setOrders: function(state, action) {
            return {
                ...state,
                orders: action.payload.orders
            }
        }
    }
});

export const { setOrders } = ordersSlice.actions;

const ordersReducer = ordersSlice.reducer;
export default ordersReducer;