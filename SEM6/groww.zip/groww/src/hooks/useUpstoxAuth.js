import { useState, useEffect } from "react";

const useUpstoxAuth = (clientId, clientSecret, redirectUri) => {
  const [authCode, setAuthCode] = useState(null);
  const [accessToken, setAccessToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Step 1: Generate Authorization Code
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get("code");
    if (code) {
      setAuthCode(code);
    } else {
      window.location.href = `https://upstox.com/api/v2/authorize?response_type=code&client_id=${clientId}&redirect_uri=${redirectUri}`;
    }
  }, [clientId, redirectUri]);

  // Step 2: Exchange Authorization Code for Access Token
  useEffect(() => {
    if (authCode) {
      const fetchAccessToken = async () => {
        try {
          setLoading(true);
          const response = await fetch("https://upstox.com/api/v2/token", {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              client_id: clientId,
              client_secret: clientSecret,
              code: authCode,
              grant_type: "authorization_code",
              redirect_uri: redirectUri,
            }),
          });

          if (!response.ok) {
            throw new Error("Network response was not ok");
          }

          const data = await response.json();
          setAccessToken(data.access_token);
        } catch (err) {
          setError(err);
        } finally {
          setLoading(false);
        }
      };

      fetchAccessToken();
    }
  }, [authCode, clientId, clientSecret, redirectUri]);

  return { accessToken, loading, error };
};

export default useUpstoxAuth;
