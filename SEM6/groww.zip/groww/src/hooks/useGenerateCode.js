import React, { useEffect, useState } from 'react'

export const useGenerateCode = ({apiKey,redirectUri}) => {
    const [code,setCode] = useState(null);

    useEffect(() => {
        window.location.href = `https://api.upstox.com/v2/login/authorization/dialog?response_type=code&client_id=${apiKey}&redirect_uri=${redirectUri}`;
    
        const checkAccessCode = () => {
          const urlParams = new URLSearchParams(window.location.search);
          setCode(urlParams.get('code'));
        };

        if(code === null) {
            checkAccessCode();
        }
      }, [apiKey, redirectUri]);
  return {code}
}
