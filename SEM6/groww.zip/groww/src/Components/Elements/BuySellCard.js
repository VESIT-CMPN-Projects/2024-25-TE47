import React, { useRef, useState } from "react";
import { BuySellTabs } from "./BuySellTabs";
import { OrderTypePill } from "./OrderTypePill";
import { useSelector, useDispatch } from "react-redux";
import SelectStockImg from "../../assets/SelectStockImg.png";
import { getLoggedInUserDetails } from "../../services/authService";
import { addToHolding, createOrder, updatePortfolio } from "../../services/updatePortfolioService";
import { setUserPortfolio } from "../../store/portfolioSlice";
import { Modal } from "./Modal";

export const BuySellCard = ({stockData,currentStockPrice}) => {
  const [buyOrSell, setBuyOrSell] = useState("BUY");
  const [orderType, setOrderType] = useState("DELIVERY");
  const [limitOrMarket, setLimitOrMarket] = useState("Market");
  const [quantityInput,setQuantityInput] = useState(1);
  const quantityRef = useRef(1);
  const limitInputRef = useRef(currentStockPrice);
  const { currentStock } = useSelector((state) => state.currentStock);
  const { userPortfolio, userHoldings } = useSelector(state => state.portfolio);
  const dispatch = useDispatch();
  const [isModalVisible,setIsModalVisible] = useState(false);

  const handleOrderSubmit = async () => {
    const orderDetail = {
      stockDetail: {
        ticker: stockData.ticker,
        name: stockData.name
      },
      quantity: parseInt(quantityInput),
      orderAt: limitOrMarket,
      orderType: orderType,
      orderPrice: limitOrMarket === "Market" ? "Market" : limitInputRef.current.value,
      averagePrice: limitOrMarket === "Market" ? currentStockPrice : limitInputRef.current.value,
      orderValue: limitOrMarket === "Market" ? currentStockPrice * quantityInput : limitInputRef.current.value * quantityInput,
      orderTime: Date.now(),
    }
    const user = await getLoggedInUserDetails();

    const res = await createOrder(orderDetail,user);
    console.log(res);
    if(res?.id === null) {
      console.log(res.status);
      console.log(res.statusText);
    } else {
      const holdingsDetail = {
        holdings: userHoldings.concat({
          stockDetail: {
            ticker: stockData.ticker,
            name: stockData.name
          },
          quantity: parseInt(quantityInput),
          averagePrice: limitOrMarket === "Market" ? currentStockPrice : limitInputRef.current.value,
        }),
        user_id: user.id
      }

      addToHolding(holdingsDetail,user);

      const revisedPortfolioObj = {
        ...userPortfolio,
        balance: userPortfolio.balance - currentStockPrice * quantityInput,
      }

      dispatch(setUserPortfolio({
        userPortfolio: revisedPortfolioObj
      }));

      updatePortfolio(revisedPortfolioObj);
      setIsModalVisible(true);
    }
  }

  return (
    <div className="border border-borderColor rounded-xl">
      <Modal name={stockData?.name} quantity={quantityInput} isModalVisible={isModalVisible} setIsModalVisible={setIsModalVisible} />
      {currentStock === null ? (
        <div className="py-40">
          <img src={SelectStockImg} className="w-[75%] mx-auto" alt="" />
          <div>
            <p className="text-center">Select a Stock</p>
            <p className="text-center">To view Investing options</p>
          </div>
        </div>
      ) : (
        <div>
          <div className="p-4 border-b border-borderColor">
            <p className="font-bold">{currentStock.stockName}</p>
            <p className="">${currentStockPrice.toFixed(2)}</p>
          </div>
          <div className="px-4 my-4 border-b border-borderColor">
            <BuySellTabs buyOrSell={buyOrSell} setBuyOrSell={setBuyOrSell} />
          </div>
          <div className="px-4 flex gap-x-3">
            <OrderTypePill
              type={"DELIVERY"}
              orderType={orderType}
              setOrderType={setOrderType}
            />
            <OrderTypePill
              type={"INTRADAY"}
              orderType={orderType}
              setOrderType={setOrderType}
            />
            <OrderTypePill
              type={"MTF"}
              orderType={orderType}
              setOrderType={setOrderType}
            />
          </div>
          <div className="p-4 mb-52">
            <div className="flex justify-between mb-4">
              <p className="font-semibold my-auto">Qty</p>
              <input
                type="text"
                className="border p-1 border-borderColor w-32 bg-black rounded text-right"
                ref={quantityRef}
                onChange={() => setQuantityInput(quantityRef.current.value)}
                value={quantityInput}
              />
            </div>
            <div className="flex justify-between">
              <div className="flex gap-x-2">
                <p className="font-semibold my-auto">Price</p>
                <button
                  className="font-bold text-md"
                  onClick={() =>
                    setLimitOrMarket(
                      limitOrMarket === "Limit" ? "Market" : "Limit"
                    )
                  }
                >
                  {limitOrMarket === "Limit" ? "Limit" : "Market"}
                  <i className="bi bi-arrow-down text-sm"></i>
                </button>
              </div>
              {limitOrMarket === "Market" ? (
                <input
                  type="text"
                  className="border p-1 border-borderColor w-32 bg-opacity-30 bg-borderColor rounded text-right text-slate-50 placeholder:text-slate-50"
                  placeholder="At Market"
                  disabled
                />
              ) : (
                <input
                  type="text"
                  ref={limitInputRef}
                  className="border p-1 border-borderColor w-32 bg-black rounded text-right text-slate-50 placeholder:text-slate-50"
                />
              )}
            </div>
          </div>
        </div>
      )}

      <div className="mx-4 py-4 border-t border-dashed border-borderColor">
        <div className="flex justify-between text-xs mb-2">
          <p>Balance : ${userPortfolio?.balance}</p>
          {currentStock === null ? <button className="text-primary-500 text-md font-semibold tracking-wide">+ ADD MONEY</button> : 
          <div>
            <p>
              Approx req. : ${(currentStockPrice * quantityInput).toLocaleString('en-IN')}
            </p>
            {(currentStockPrice * quantityInput) > userPortfolio?.balance && (
              <p className="text-danger">
                Insufficient balance
              </p>
            )}
          </div>}
        </div>
        {currentStock === null ? null : (
          <button
            className={`${
              buyOrSell === "BUY" ? "bg-primary-500" : "bg-danger"
            } hover:bg-opacity-95 w-full rounded-lg p-2`}
            disabled={(currentStockPrice * quantityInput) > userPortfolio?.balance} 
            onClick={handleOrderSubmit}
          >
            {buyOrSell === "BUY" ? "Buy" : "Sell"}
          </button>
        )}
      </div>
    </div>
  );
};
