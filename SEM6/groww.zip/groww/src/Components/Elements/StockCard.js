import React from 'react'
import Dummy from "../../assets/Dummy.jpg";
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

export const StockCard = ({stockName}) => {
    const stockPrize = (Math.random()*200 + 1).toFixed(2);
    const plPerc = (Math.random()*2).toFixed(2);
    const randomInt = Math.floor(Math.random()*2 + 1);
    const navigate = useNavigate();
  return (
    <motion.div className='bg-cardColor cursor-pointer w-full px-4 py-3 rounded-lg border border-borderColor' onClick={() => navigate(`/stock/${stockName}`)} initial={false} whileHover={{scale: 1.02, transition: { duration: .2 } }}>
        <div className='mb-10'>
            <img src={Dummy} className="bg-white rounded" alt="" width={"38px"} height={"38px"} />
            <p className='font-semibold'>{stockName}</p>
        </div>
        <div>
            <p className='font-semibold'>${stockPrize}</p>
            <p className={`${randomInt === 1 ? 'text-primary-500' : 'text-danger'}`}>{((stockPrize*plPerc)/100).toFixed(2)}  ({plPerc}%)</p>
        </div>
    </motion.div>
  )
}
