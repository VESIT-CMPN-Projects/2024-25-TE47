import React, { useRef } from "react";
import { getLoggedInUserDetails } from "../../services/authService";
import { createWatchlist } from "../../services/watchlistService";
import { useDispatch } from "react-redux";
import { addWatchlist } from "../../store/watchlistSlice";

export const CreateWatchListModal = ({ setIsCreateWatchlistModalVisible }) => {
    const inputRef = useRef();
    const dispatch = useDispatch();

    const handleSubmit = async e => {
      e.preventDefault();
      const user = await getLoggedInUserDetails();
      const watchlistObj = {
        name: inputRef.current.value,
        user,
        stocks:[],
        number_of_items: 0,
        user_id: user.id,
      }

      try {
        const res = await createWatchlist(watchlistObj);
        if(res?.id) {
          dispatch(addWatchlist({watchlist: watchlistObj}));
        }
        setIsCreateWatchlistModalVisible(false);
      } catch(e) {
        console.log(e);
      }
    }

    return (
        <div className="bg-black px-5 py-7 rounded-lg absolute w-[25%] top-[35%] left-[37.5%]">
            <div className="flex justify-between align-middle mb-6">
                <h2 className="text-xl mt-2 font-semibold">Create Watchlist</h2>
                <button className="px-4 py-1 border border-borderColor rounded-xl" onClick={() => setIsCreateWatchlistModalVisible(false)}>
                    <p className="text-xl font-semibold">x</p>
                </button>
            </div>
            <form action="" onSubmit={handleSubmit}>
                <input
                    type="text"
                    ref={inputRef}
                    className="bg-cardColor w-full mb-7 p-2 focus:outline-0 border-b-2 border-borderColor"
                    placeholder="Enter Name"
                />
                <button type="submit" className="bg-primary-500 hover:bg-primary-600 p-1 rounded-lg w-full">
                    Create
                </button>
            </form>
        </div>
    );
};
