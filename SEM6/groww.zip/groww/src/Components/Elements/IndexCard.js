import React from 'react'

export const IndexCard = ({insKey,indexName}) => {
    const currentIndex = (Math.random()*50000 + 1).toFixed(2);
    const currentPerc = parseFloat((Math.random()*3 + 1).toFixed(2));
    const randomInt = Math.floor(Math.random()*2 + 1);
  return (
    <div className='text-white text-sm bg-cardColor p-3 md:min-w-[15rem] min-w-fit rounded-md shadow-lg shadow-black-5/10 cursor-pointer border border-borderColor'>
        <div className='mb-2'>{indexName}</div>
        <div className='flex gap-2 text-semibold'>
            <div>
                {currentIndex}
            </div>
            <div className={`flex gap-1 ${randomInt === 1 ? 'text-primary-500' : 'text-danger'}`}>
                <p>{((currentIndex*currentPerc)/100).toFixed(2)}</p>
                <p>({currentPerc}%)</p>
            </div>
        </div>
    </div>
  )
}
