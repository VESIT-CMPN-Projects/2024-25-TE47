import React, { useState } from "react";
import { WatchListRow } from "./WatchListRow";
import { getLoggedInUserDetails } from "../../services/authService";
import { updateWatchlist } from "../../services/watchlistService";
import { useDispatch, useSelector } from "react-redux";
import { setWatchlists } from "../../store/watchlistSlice";

export const AddStockToWatchListModal = ({ tickerData,setIsWatchlistModalVisible }) => {
    const [selectedWatchlist, setSelectedWatchlist] = useState(null);
    const watchlists = useSelector(state => state.watchlist.watchlists);
    const dispatch = useDispatch();

    const stockTickerObj = {
        name: tickerData?.name,
        ticker: tickerData?.ticker,
    };

    const handleSelect = (watchlist) => {
        if (selectedWatchlist === watchlist) setSelectedWatchlist(null);
        else setSelectedWatchlist(watchlist);
    };

    const handleAddToWatchlist = async () => {
        const user = await getLoggedInUserDetails();
        const currentWatchlistObj = watchlists.filter(watchlist => watchlist.name === selectedWatchlist)[0];
        console.log(currentWatchlistObj);
        const watchlistObj = {
            name: selectedWatchlist,
            user,
            stocks: currentWatchlistObj.stocks.concat(stockTickerObj),
            number_of_items: currentWatchlistObj.number_of_items + 1,
            user_id: user.id,
        };

        updateWatchlist(watchlistObj, currentWatchlistObj.id);
        dispatch(setWatchlists({
            watchlists: watchlists.map(watchlist => watchlist.name === selectedWatchlist ? watchlistObj : watchlist)
        }));
    };

    return (
        <div className="bg-black border border-borderColor px-5 py-7 rounded-lg absolute w-[25%] top-[35%] left-[37.5%]">
            <div className="flex justify-between align-middle mb-6">
                <h2 className="text-xl mt-2 font-semibold">Add Stock to</h2>
                <button className="px-4 py-1 border border-borderColor rounded-xl" onClick={() => setIsWatchlistModalVisible(false)}>
                    <p className="text-xl font-semibold">x</p>
                </button>
            </div>
            <div>
                {watchlists.map((watchlist) => (
                    <WatchListRow
                        watchlist={watchlist}
                        handleSelect={handleSelect}
                        selectedWatchlist={selectedWatchlist}
                        key={watchlist.name}
                    />
                ))}
            </div>
            <button
                className="bg-primary-500 hover:bg-primary-600 p-1 rounded-lg w-full"
                onClick={handleAddToWatchlist}
                // disabled={selectedWatchlist !== null}
            >
                Save
            </button>
        </div>
    );
};
