import React from 'react'

export const ProductAndToolCard = ({productName,imgURL}) => {
  return (
    <div className='w-full cursor-pointer'>
        <div className='bg-cardColor rounded-lg h-[84px] p-4 mb-2'>
            <img src={imgURL} alt="" className='max-h-[56px] h-[56px] w-[56px] m-auto' />
        </div>
        <p className='text-center text-sm font-semibold'>
            {productName}
        </p>
    </div>
  )
}
