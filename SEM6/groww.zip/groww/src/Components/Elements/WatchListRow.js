import React from "react";

export const WatchListRow = ({watchlist, selectedWatchlist, handleSelect}) => {
    return (
        <div className="flex justify-between mb-2">
            <button className="flex gap-x-3 align-middle" onClick={() => handleSelect(watchlist.name)}>
                <div
                    className="border p-3 me-1 rounded-lg border-borderColor"
                >
                    <p className="font-bold">
                        <i
                            className={`bi ${
                                selectedWatchlist === watchlist.name
                                    ? "bi-bookmark-fill"
                                    : "bi-bookmark"
                            } text-primary-500`}
                        ></i>
                    </p>
                </div>
                <p className="text-xl mt-2">{watchlist.name}</p>
            </button>
            <div className="mt-2 text-gray-500 w-fit">
                <p>{watchlist.number_of_items} items</p>
            </div>
        </div>
    );
};
