import React from "react";

export const BuySellTabs = ({
  buyOrSell,
  setBuyOrSell,
}) => {
    const normalStyle = "inline-block text-sm text-bold p-2 border-b-2 border-transparent rounded-t-lg";
    const activeStyle = "inline-block text-sm text-bold p-2 border-b-2 rounded-t-lg active dark:text-primary-500 dark:border-primary-500";
  return (
    <div className="text-sm font-medium text-center dark:text-gray-400 dark:border-gray-700">
      <ul className="flex flex-wrap -mb-px">
        <li className="me-2">
          <button
            className={`${buyOrSell === 'BUY' ? activeStyle : normalStyle}`}
            onClick={() => setBuyOrSell("BUY")}
          >
            BUY
          </button>
        </li>
        <li className="me-2">
          <button
            className={`${buyOrSell === 'SELL' ? activeStyle : normalStyle}`}
            aria-current="page"
            onClick={() => setBuyOrSell("SELL")}
          >
            SELL
          </button>
        </li>
      </ul>
    </div>
  );
};
