import React from "react";

export const Modal = ({name,quantity,isModalVisible,setIsModalVisible}) => {
    return (
        <div
            id="popup-modal"
            tabIndex="-1"
            className={`${isModalVisible ? '' : 'hidden'} overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full`}
        >
            <div className="relative p-4 w-full h-full">
                <div className="absolute  top-[43%] left-[40%] w-fit bg-black border border-borderColor rounded-lg shadow-sm p-3">
                    <button
                        type="button"
                        onClick={() => setIsModalVisible(!isModalVisible)}
                        className="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        data-modal-hide="popup-modal"
                    >
                        <svg
                            className="w-3 h-3"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 14 14"
                        >
                            <path
                                stroke="currentColor"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                            />
                        </svg>
                        <span className="sr-only">Close modal</span>
                    </button>
                    <div className="p-4 md:p-5 text-center">
                        <div className="rounded-full">
                            <i className="bi bi-check-circle-fill text-3xl text-primary-500 bg-white"></i>
                        </div>
                        <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">
                            {quantity} {quantity > 1 ? 'shares' : 'share'} bought for stock {name}
                        </h3>
                        <button
                            data-modal-hide="popup-modal"
                            type="button"
                            className="text-white bg-primary-500 hover:bg-primary-300 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center"
                        >
                            Yes, I'm sure
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
