import React from "react";

export const OrderTypePill = ({ type, orderType, setOrderType }) => {
  const activePill = "text-xs px-2 py-1 border rounded-[10px]";
  const inactivePill = "text-xs px-2 py-1 border border-borderColor rounded-[10px]";
  return (
    <button
      className={`${orderType === type ? activePill : inactivePill}`}
      onClick={() => setOrderType(type)}
    >
      {type.substring(0,1)}{type.substring(1).toLowerCase()}
    </button>
  );
};
