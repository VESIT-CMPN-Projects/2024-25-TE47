import React, { useEffect, useState } from "react";
import { Icons } from "./Components/Icons";
import { NavigationalComponent } from "./Components/NavigationalComponent";
import { InputComponent } from "./Components/InputComponent";
import { MobileViewButtons } from "./Components/MobileViewButtons";
import { DropdownLoggedInMenu } from "./Components/DropdownLoggedInMenu";
import { isLoggedIn } from "../../../services/authService";
import { DropdownLoggedOut } from "./Components/DropdownLoggedOut";

export const Header = () => {
  const [show, setShow] = useState(false);
  const [isDropdownVisible,setIsDropdownVisible] = useState(false);
  const [isUserLoggedIn,setIsUserLoggedIn] = useState(false);

  useEffect(() => {
    const res = isLoggedIn();
    setIsUserLoggedIn(res);
  },[])
  return (
    <>
      <nav className="bg-white border-b-2 mb-6 border-borderColor dark:bg-black">
        <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
          <div className="flex justify-between space-x-4">
            <a
              href="http://localhost:3000"
              className="flex items-center space-x-3 rtl:space-x-reverse"
            >
              {/* <img src={Groww} className="h-8" alt="Flowbite Logo" /> */}
              <span className="self-center text-3xl font-semibold whitespace-nowrap dark:text-white tracking-wider">
                <span className="text-primary-500">In</span>vest<span className="text-primary-500">Pr</span>o
              </span>
            </a>
            <NavigationalComponent />
          </div>
          <div className="md:min-w-[33%] hidden md:block">
            <InputComponent />
          </div>
          <div className="hidden md:block">
            <Icons isDropdownVisible={isDropdownVisible} setIsDropdownVisible={setIsDropdownVisible} />
            { isDropdownVisible && (<div className="relative">
              {isUserLoggedIn ? <DropdownLoggedInMenu setIsDropdownVisible={setIsDropdownVisible} /> : <DropdownLoggedOut setIsDropdownVisible={setIsDropdownVisible} />}
            </div>)}
          </div>
          <div className="md:hidden sm-block">
            <MobileViewButtons show={show} setShow={setShow} />
          </div>
        </div>

        <div
          className={`${
            show ? "" : "hidden"
          } md:hidden sm-block flex flex-col px-3 pb-2 space-y-4`}
        >
          <InputComponent />
          <div className="self-end pb-2">
            <Icons isDropdownVisible={isDropdownVisible} setIsDropdownVisible={setIsDropdownVisible} />
          </div>
        </div>
      </nav>
      {/* <hr className="h-px mb-4 bg-gray-200 border-0 dark:bg-gray-700"></hr> */}
    </>
  );
};
