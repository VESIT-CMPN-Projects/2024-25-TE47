import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getLoggedInUserDetails, isLoggedIn, logout } from "../../../../services/authService";

export const DropdownLoggedInMenu = ({setIsDropdownVisible}) => {
    const [user,setUser] = useState();
    const navigate = useNavigate();
    useEffect(() => {
        async function getUserDetails() {
            const userDetails = await getLoggedInUserDetails();
            setUser(userDetails);
        }

        if(isLoggedIn()) {
            getUserDetails();
        }
    },[]);

    function handleLogout() {
        logout();
        setIsDropdownVisible(false);
        navigate("/");
    }
    return (
        <div className="text-white absolute top-3">
            <div
                id="dropdownDivider"
                className="z-10 rounded-lg shadow w-fit p-2 dark:bg-black border border-borderColor dark:divide-gray-600"
            >
                <div className="py-2 text-sm px-2">
                    <p>{user && user?.name}</p>
                    <p>{user && user?.email}</p>
                </div>
                <ul
                    className="py-2 text-sm px-2"
                    aria-labelledby="dropdownDividerButton"
                >
                    <li className="border-b border-borderColor">
                        <Link
                            to={'/orders'}
                            className="block py-3 hover:bg-cardColor hover:text-white"
                            onClick={() => setIsDropdownVisible(false)}
                        >
                            <div className="flex justify-between gap-x-2">
                                <i className="bi bi-receipt"></i>
                                <div className="w-full flex justify-between">
                                    <p>All Orders</p>
                                    <i className="bi bi-chevron-right"></i>
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/investments"
                            className="block py-2 hover:bg-cardColor hover:text-white"
                            onClick={() => setIsDropdownVisible(false)}
                        >
                            <div className="flex justify-between gap-x-2">
                                <i className="bi bi-graph-up-arrow"></i>
                                <div className="w-full flex justify-between">
                                    <p>Investments</p>
                                    <i className="bi bi-chevron-right"></i>
                                </div>
                            </div>
                        </Link>
                    </li>
                </ul>
                <div className="py-2 flex justify-end">
                    <button className="rounded-lg text-sm border border-borderColor px-4 py-2"
                    onClick={handleLogout}
                    >
                        Log Out
                    </button>
                </div>
            </div>
        </div>
    );
};
