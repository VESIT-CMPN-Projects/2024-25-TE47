import React from "react";
import { Link } from "react-router-dom";

export const NavigationalComponent = () => {
  return (
    <div
      className="items-center justify-between  flex w-auto"
      id="navbar-search"
    >
      <ul className="flex p-2 md:p-0 font-medium rounded-lg bg-black space-x-2 md:space-x-6 rtl:space-x-reverse flex-row md:mt-0 md:border-0">
        <li>
          <Link
            to="/"
            className="block mt-1 py-2 px-2 text-primary-500 rounded md:bg-transparent md:p-0 "
            aria-current="page"
          >
            Explore
          </Link>
        </li>
        <li>
          <Link
            to="/investments"
            className="block mt-1 py-2 px-3 text-slate-100 rounded hover:text-primary-500 md:p-0"
          >
            Investments
          </Link>
        </li>
      </ul>
    </div>
  );
};
