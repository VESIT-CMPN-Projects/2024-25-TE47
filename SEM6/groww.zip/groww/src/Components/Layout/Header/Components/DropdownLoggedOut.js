import React from "react";
import { Link } from "react-router-dom";

export const DropdownLoggedOut = ({ setIsDropdownVisible }) => {
    return (
        <div className="text-white absolute top-3">
            <div
                id="dropdownDivider"
                className="z-10 rounded-lg shadow w-fit p-2 dark:bg-black border border-borderColor dark:divide-gray-600"
            >
                <div className="py-2 text-sm px-2">
                    <p>Please Login to enjoy the services!!</p>
                </div>
                <ul
                    className="py-2 text-sm px-2"
                    aria-labelledby="dropdownDividerButton"
                >
                    <li className="border-b border-borderColor">
                        <Link
                        to="/login"
                            className="block py-3 hover:bg-cardColor hover:text-white"
                            onClick={() => setIsDropdownVisible(false)}
                        >
                            <div className="flex justify-between gap-x-2">
                                <i className="bi bi-box-arrow-in-right"></i>
                                <div className="w-full flex justify-between">
                                    <p>Login</p>
                                    <i className="bi bi-chevron-right"></i>
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/register"
                            className="block py-2 hover:bg-cardColor hover:text-white"
                            onClick={() => setIsDropdownVisible(false)}
                        >
                            <div className="flex justify-between gap-x-2">
                                <i className="bi bi-r-circle"></i>
                                <div className="w-full flex justify-between">
                                    <p>Register</p>
                                    <i className="bi bi-chevron-right"></i>
                                </div>
                            </div>
                        </Link>
                    </li>
                </ul>
            </div>
        </div>
    );
};
