import React, { useEffect, useRef, useState } from "react";
import { InputSelectComponent } from "./InputSelectComponent";
import { useForm } from "react-hook-form";
import { useFetch } from "../../../../hooks/useFetch";
import useClickOutside from "../../../../hooks/useClickOutside";

export const InputComponent = () => {
  const {register,watch} = useForm();

  const {data,loading,error,setUrl} = useFetch();

  const [dropdownSearchStockMenu,setDropdownSearchStockMenu] = useState(false);

  const dropdownRef = useRef();

  const input = watch("searchStock");

  useEffect(() => {
    const timeout = setTimeout(() => {
      if(input)
        (async () => {
          getTickers(input);
        })();
    },500);

    return () => clearTimeout(timeout);
  },[input]);

  

  useClickOutside(dropdownRef,() => {
    setDropdownSearchStockMenu(false);
  });

  const getTickers = async (name) => {
    setDropdownSearchStockMenu(true);
    const URL = `${process.env.REACT_APP_STOCK_API_BASE_URL}/v3/reference/tickers?search=${name}&market=stocks&active=true&limit=5&apiKey=${process.env.REACT_APP_STOCK_API_KEY}`
    setUrl(URL);
  }

  return (
    <div className="relative my-2 w-full">
      <div className="absolute inset-y-0 flex items-center ps-3 pointer-events-none">
        <svg
          className="w-4 h-4 text-gray-500 dark:text-gray-400"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 20 20"
        >
          <path
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
          />
        </svg>
      </div>
      <input
        type="text"
        className="block w-full p-2 ps-10 text-sm text-gray-900 border  rounded bg-black dark:bg-black dark:border-borderColor dark:placeholder-slate-400 dark:text-white focus:outline-none"
        placeholder="What are you looking for today?"
        {...register("searchStock")}
      />
      <div className="absolute w-full bg-black border border-borderColor border-t-0 divide-y divide-borderColor z-50" ref={dropdownRef}>
        {input && dropdownSearchStockMenu && data && data.results.map(ticker => <InputSelectComponent ticker={ticker} key={ticker.name} />)}
        {error && console.log(error)}
      </div>
    </div>
  );
};
