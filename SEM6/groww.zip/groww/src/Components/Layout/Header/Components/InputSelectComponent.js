import React from "react";
import { Link } from "react-router-dom";

export const InputSelectComponent = ({ ticker }) => {
  return (
    <Link to={`/stock/${ticker.ticker}`}>
      <div className="py-3 px-6 flex gap-x-4 hover:bg-cardColor cursor-pointer">
        <div className="rounded-[100%] w-fit h-fit my-auto border p-[3px] bg-borderColor">
          <i className="bi bi-arrow-up-right text-sm text-white"></i>
        </div>
        <div className="text-sm text-white">
          <p className="text-md">{ticker.name}</p>
          <p>{ticker.ticker}</p>
        </div>
      </div>
    </Link>
  );
};
