import React from "react";
import { Link } from "react-router-dom";

export const Icons = ({isDropdownVisible,setIsDropdownVisible}) => {
  return (
    <div className="text-slate-300 text-xl flex space-x-8">
      <i className="bi bi-bell cursor-pointer"></i>
      <Link to={"/wallet"}><i className="bi bi-wallet2 cursor-pointer"></i></Link>
      <i className="bi bi-cart cursor-pointer"></i>
      <i className="bi bi-person-circle cursor-pointer" onClick={() => setIsDropdownVisible(!isDropdownVisible)}></i>
    </div>
  );
};
