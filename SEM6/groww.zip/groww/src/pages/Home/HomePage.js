import React, { useState } from "react";
import { IndexSection } from "./Components/IndexSection";
import { MostBought } from "./Components/MostBought";
import { ProductsAndTools } from "./Components/ProductsAndTools";
import { StocksInNews } from "./Components/StocksInNews";
import { YourInvestments } from "./Components/YourInvestments";
import { WatchListSection } from "./Components/WatchListSection";
import { CreateWatchListModal } from "../../Components";

export const HomePage = () => {
  const [isCreateWatchlistModalVisible, setIsCreateWatchlistModalVisible] = useState(false);
  
  return (
    <main className="flex gap-8">
      <div className="md:w-[65%] w-full">
        <IndexSection />
        <MostBought />
        <ProductsAndTools />
        <StocksInNews />
      </div>
      <div className="w-full md:block hidden">
        <YourInvestments />
        <WatchListSection />
      </div>
      {isCreateWatchlistModalVisible && <CreateWatchListModal setIsCreateWatchlistModalVisible={setIsCreateWatchlistModalVisible} />}
    </main>
  );
};
