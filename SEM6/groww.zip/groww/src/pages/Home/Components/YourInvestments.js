import React from 'react'
import { SectionHeader } from "./SectionHeader"

export const YourInvestments = () => {
  const amountInvested = 10000;
  const plPerc = (Math.random()*10).toFixed(2);
  const randomInt = Math.floor(Math.random()*2 + 1);
  const plAmount = Math.round((amountInvested*plPerc)/100);
  return (
    <div className='mb-6'>
        <div className='flex justify-between'>
          <SectionHeader title="Your Investments" />
          <div className='my-4 text-sm bottom-0'>
            <p className='mt-1 text-primary-500 cursor-pointer'>Dashboard</p>
          </div>
        </div>
        <div className='p-4 flex justify-between border border-borderColor rounded-xl'>
          <div>
            <p className={`${randomInt === 1 ? 'text-primary-500' : 'text-danger'}`}>{`${randomInt === 1 ? "+" : "-"}`} ${plAmount}</p>
            <p>Total Returns</p>
          </div>
          <div>
            <p className='text-end'>${`${randomInt === 1 ? amountInvested + plAmount : amountInvested - plAmount}`}</p>
            <p>Current Value</p>
          </div>
        </div>
    </div>
  )
}
