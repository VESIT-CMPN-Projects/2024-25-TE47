import React from 'react'
import { SectionHeader } from './SectionHeader'
import { ProductAndToolCard } from '../../../Components'

export const ProductsAndTools = () => {
    const productArr = [
        {
            name: 'F&O',
            imgURL: 'https://storage.googleapis.com/groww-assets/web-assets/img/stock/fno_mint_dark.svg'
        },
        {
            name: 'Events',
            imgURL: 'https://storage.googleapis.com/groww-assets/web-assets/img/stock/calendar_mint_dark.svg'
        },
        {
            name: 'Intraday',
            imgURL: 'https://storage.googleapis.com/groww-assets/web-assets/img/stock/intraday_mint_dark.svg'
        },
        {
            name: 'IPO',
            imgURL: 'https://storage.googleapis.com/groww-assets/web-assets/img/stock/ipo_mint_dark.svg'
        },
        {
            name: 'Screener',
            imgURL: 'https://storage.googleapis.com/groww-assets/web-assets/img/stock/screener_mint_dark.svg'
        }
    ]
  return (
    <div className='mb-6'>
        <SectionHeader title="Products And Tools" />
        <div className='flex justify-between gap-5'>
            {productArr.map(product => <ProductAndToolCard productName={product.name} imgURL={product.imgURL} key={product.name} />)}
        </div>
    </div>
  )
}
