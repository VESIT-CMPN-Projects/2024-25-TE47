import React from 'react'

export const SectionHeader = ({title}) => {
  return (
    <div className='text-white text-xl font-semibold my-4'>
        {title}
    </div>
  )
}
