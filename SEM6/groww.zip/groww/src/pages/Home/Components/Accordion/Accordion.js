import React, { useState } from "react";
import { AccordianStockCard } from "./AccordionStockCard";
import { motion } from "framer-motion";

const listVariants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { 
      type: "spring",
      bounce: 0,
      duration: 0.7,
      delayChildren: 0.3,
      staggerChildren: 0.05
    },
  }
};

export const Accordian = ({ watchlist }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b-2 border-borderColor">
      <h2>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className={`flex items-center justify-between w-full p-4 font-medium rtl:text-right ${open ? 'bg-cardColor' : ''}`}
          data-accordion-target="#accordion-open-body-1"
          aria-expanded="true"
          aria-controls="accordion-open-body-1"
        >
          <span className="grid grid-rows-2">
            <span className="text-md text-left font-bold">{watchlist.name}</span>
            <span className="text-left font-thin text-sm">
              {watchlist.number_of_items} items
            </span>
          </span>
          <svg
            data-accordion-icon=""
            className="w-3 h-3 shrink-0"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 10 6"
          >
            <motion.path
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M9 5 5 1 1 5"
              animate={{
                rotate: open ? 0 : 180,
                transition: { duration: 0.3 },
              }}
            ></motion.path>
          </svg>
        </button>
      </h2>
      {open && <hr className="h-px border-0 bg-borderColor"></hr>}
      <div
        id="accordion-open-body-1"
        className={!open ? "hidden" : ""}
        aria-labelledby="accordion-open-heading-1"
      >
        <div>
          <motion.div
            variants={listVariants}
            initial="hidden"
            animate={!open ? "hidden" : "visible"}
          >
            {watchlist.stocks.map((stock) => (
              <AccordianStockCard name={stock.name} ticker={stock.ticker} key={stock} />
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
};
