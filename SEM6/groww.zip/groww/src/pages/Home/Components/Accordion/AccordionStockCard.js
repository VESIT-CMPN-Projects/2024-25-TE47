import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
};

export const AccordianStockCard = ({ name,ticker }) => {
  const stockPrize = (Math.random() * 200 + 1).toFixed(2);
  const plPerc = (Math.random() * 2).toFixed(2);
  const randomInt = Math.floor(Math.random() * 2 + 1);
  return (
    <>
      <motion.div
        className="px-4 py-3 flex justify-between text-sm font-semibold border-b-2 border-borderColor"
        variants={itemVariants}
      >
        <Link to={`http:localhost:3000/stock/${ticker}`} className="py-auto hover:underline text-white">{name}</Link>
        <div>
          <p className="text-right">${stockPrize}</p>
          <p
            className={`${
              randomInt === 1 ? "text-primary-500" : "text-danger"
            } text-right`}
          >
            {((stockPrize * plPerc) / 100).toFixed(2)} ({plPerc}%)
          </p>
        </div>
      </motion.div>
      {/* <hr className="h-px border-0 bg-borderColor"></hr> */}
    </>
  );
};
