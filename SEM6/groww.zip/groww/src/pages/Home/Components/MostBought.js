import React from 'react'
import { SectionHeader } from './SectionHeader'
import { StockCard } from '../../../Components'

export const MostBought = () => {
    const mostBoughtStocks = ["IRFC","Zomato","Tata Steel","GTL Infrastructure"];
  return (
    <div className='mb-7'>
        <SectionHeader title="Most Bought On InvestPro" />
        <div className='md:flex grid grid-cols-2 justify-between gap-4'>
            {mostBoughtStocks.map((stockName,i) => <StockCard stockName={stockName} key={i} />)}
        </div>
    </div>
  )
}
