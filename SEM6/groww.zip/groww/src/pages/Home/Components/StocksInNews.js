import React from 'react'
import { SectionHeader } from "./SectionHeader";
import { StockCard } from '../../../Components';

export const StocksInNews = () => {
    const stocksInNews = ["DLF","SBI","Marico","Crompton Greaves"];
  return (
    <div>
        <SectionHeader title="Stocks In News" />
        <div className='md:flex grid grid-cols-2 justify-between gap-4'>
            {stocksInNews.map((stockName,i) => <StockCard stockName={stockName} key={i} />)}
        </div>
    </div>
  )
}
