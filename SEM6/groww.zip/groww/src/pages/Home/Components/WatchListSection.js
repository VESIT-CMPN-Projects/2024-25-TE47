import React from "react";
import { SectionHeader } from "./SectionHeader";
import { Accordian } from "./Accordion/Accordion";
import { LastCreateButton } from "./Accordion/LastCreateButton";
import { useSelector } from "react-redux";

export const WatchListSection = () => {
  const watchlists = useSelector(state => state.watchlist.watchlists);
  return (
    <div>
      <div className="flex justify-between">
        <SectionHeader title="All Watchlists" />
        <div className="my-4 text-sm bottom-0">
          <p className="mt-1 text-primary-500 cursor-pointer">View All</p>
        </div>
      </div>
      <div className="border border-borderColor rounded-lg">
        {watchlists && watchlists.map(watchlist => <Accordian watchlist={watchlist} key={watchlist.id} />)}
        <LastCreateButton />
      </div>
    </div>
  );
};
