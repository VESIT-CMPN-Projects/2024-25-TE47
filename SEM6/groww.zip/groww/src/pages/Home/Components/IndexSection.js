import React from 'react'
import { SectionHeader } from './SectionHeader'
import { IndexCard } from '../../../Components';

export const IndexSection = () => {
  const indexArr = ["NIFTY 50","SENSEX","BANKNIFTY","FINNIFTY","MIDCPNIFTY","BANKEX"];
  return (
    <div className='mb-7'>
        <SectionHeader title="Index" />
        <div className='flex gap-x-3 snap-start snap-x overflow-x-auto no-scrollbar pb-2'>
          {indexArr.map((indexName,i) => <IndexCard indexName={indexName} key={i} /> )}
        </div>
    </div>
  )
}
