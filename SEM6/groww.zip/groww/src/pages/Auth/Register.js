import React, { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { getSessionData, register } from "../../services/authService";
import { toast } from "react-toastify";
import RegisterImage from "../../assets/RegisterImage.svg";
import { createPorfolio } from "../../services/createPortfolioService";

export const Register = () => {
  
  const nameRef = useRef("");
  const emailRef = useRef("");
  const passwordRef = useRef("");
  const navigate = useNavigate();

  const handleSubmit = async (evt) => {
    evt.preventDefault();
    handleClick();
  };

  const handleClick = async () => {
    try {
      const authDetails = {
        name: nameRef.current.value,
        email: emailRef.current.value,
        password: passwordRef.current.value,
      };

      const res = await register(authDetails);
      
      await createPorfolio(res);

      navigate("/");
      window.location.reload();
    } catch (error) {
      // toast.error(error.message, {
      //   position: toast.POSITION.TOP_RIGHT,
      //   // console.log(error);
      // });
    }
  };

  return (
    <main className="">
      <div className="bg-gray-800 flex flex-col md:flex-row p-10 rounded-3xl md:space-x-8 space-x-0 py-auto">
        <div className="w-full">
          <img src={RegisterImage} alt="" />
        </div>
        <div className="w-full h-full my-auto">
          <h2 className="text-4xl text-primary-500 mb-4">Register</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <div>
                <label
                  htmlFor="name"
                  className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >
                  Username
                </label>
                <input
                  type="text"
                  id="name"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="Username"
                  required
                  ref={nameRef}
                />
              </div>
            </div>
            <div className="mb-6">
              <label
                htmlFor="email"
                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >
                Email address
              </label>
              <input
                type="email"
                id="email"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                placeholder="Email"
                required
                ref={emailRef}
              />
            </div>
            <div className="mb-6">
              <label
                htmlFor="password"
                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >
                Password
              </label>
              <input
                type="password"
                id="password"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                placeholder="•••••••••"
                required
                ref={passwordRef}
              />
            </div>
            <div className="flex items-center justify-between">
              <button
                className="bg-primary-500 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline"
                type="submit"
              >
                Register
              </button>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
};
