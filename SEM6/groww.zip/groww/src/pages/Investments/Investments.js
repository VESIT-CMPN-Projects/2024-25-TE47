import React from 'react'
import { IndexSection } from './Components/IndexSection'
import { InvestmentSection } from './Components/InvestmentSection'
import { BuySellCard } from '../../Components'

export const Investments = () => {
  return (
    <main className='flex gap-x-6 my-4'>
        <div className='w-[65%]'>
            <IndexSection />
            <InvestmentSection />
        </div>
        <div className='w-full'>
            <BuySellCard />
        </div>
    </main>
  )
}
