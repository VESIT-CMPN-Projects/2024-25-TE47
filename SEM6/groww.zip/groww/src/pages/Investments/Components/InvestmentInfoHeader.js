import React from 'react'
import { Link } from 'react-router-dom';

export const InvestmentInfoHeader = () => {
    const investedValue = 10000;
  const plPerc = (Math.random() * 5).toFixed(2);
  const randomInt = Math.floor(Math.random() * 2 + 1);
  const oneDayReturns = Math.round(Math.random() * 200);
  const oneDayPerc = (((oneDayReturns)/(investedValue))*100).toFixed(2);
  return (
    <div className="bg-primary-100 text-sm font-semibold rounded-t-md px-5 py-6 flex gap-x-4 justify-between">
        <div className="my-auto">
          <p className="text-2xl mb-1 font-semibold">
            $
            {`${
              randomInt === 1
                ? (investedValue * plPerc) / 100 + investedValue
                : investedValue - (investedValue * plPerc) / 100
            }`}
          </p>
          <p className="text-md">Current Value</p>
        </div>
        <div className="flex gap-x-5">
          <div className="">
            <p className="mb-1">Invested Value</p>
            <p className="mb-1">Total Returns</p>
            <p>1D Returns</p>
          </div>
          <div className="text-left">
            <p className="mb-1">${investedValue}</p>
            <p className={`mb-1 ${randomInt === 1 ? 'text-primary-500' : 'text-danger'}`}>
              {randomInt === 1 ? "+" : "-"}$
              {Math.round((investedValue * plPerc) / 100)}({plPerc}%)
            </p>
            <p className={`mb-1 ${randomInt === 1 ? 'text-primary-500' : 'text-danger'}`}>
              {randomInt === 1 ? "+" : "-"}$
              {oneDayReturns}({oneDayPerc}%)
            </p>
          </div>
        </div>
        <div className="my-auto">
          <Link to={'/orders'} className="text-primary-500 align-text-bottom">View All Orders</Link>
        </div>
      </div>
  )
}
