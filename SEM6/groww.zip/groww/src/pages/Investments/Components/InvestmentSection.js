import React from 'react'
import { InvestmentTable } from './InvestmentTable'

export const InvestmentSection = () => {
  return (
    <div>
      <h2 className='text-xl font-semibold mb-6'>Holdings (10)</h2>
      <InvestmentTable />
    </div>
  )
}
