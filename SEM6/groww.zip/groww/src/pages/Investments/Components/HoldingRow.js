import React from "react";
import { ChartComponent } from "./ChartComponent";
import { setCurrentStock } from "../../../store/currentStockSlice";
import { useDispatch } from "react-redux";

export const HoldingRow = ({ stockName, i }) => {
  const randomInt = Math.floor(Math.random() * 2 + 1);
  const dispatch = useDispatch();
  return (
    <tr className="border-b border-borderColor last:border-none hover:bg-cardColor cursor-pointer" onClick={() => dispatch(setCurrentStock({currentStock: {stockName,averagePrice: 100}}))}>
      <td className="px-6 py-4 font-medium whitespace-nowrap text-left">
        <button className="hover:underline hover:text-primary-500">
          {stockName}
        </button>
      </td>
      <td className="px-6 py-4 text-right">
        <ChartComponent randomInt={randomInt} id={`chart${i}`} />
      </td>
      <td className="px-6 py-4 text-right">$100</td>
      <td className="px-6 py-4 text-right">$200</td>
      <td className="px-6 py-4 text-right">$300</td>
    </tr>
  );
};
