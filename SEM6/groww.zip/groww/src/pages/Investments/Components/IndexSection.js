import React from "react";
import { IndexCard } from "../../../Components";

export const IndexSection = () => {
  const indexArr = [
    "NIFTY 50",
    "SENSEX",
    "BANKNIFTY",
    "FINNIFTY",
    "MIDCPNIFTY",
    "BANKEX",
  ];
  return (
    <div className="flex my-3 mb-6 gap-x-3 snap-start snap-x overflow-x-auto no-scrollbar pb-2">
      {indexArr.map((indexName, i) => (
        <IndexCard indexName={indexName} key={i} />
      ))}
    </div>
  );
};
