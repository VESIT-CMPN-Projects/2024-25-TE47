import React from 'react'

export const ActualTableHeader = ({tableHead}) => {
    
  return (
    <th className='px-6 py-4 text-right first:text-left font-semibold text-xs border-b border-borderColor border-dashed'>
        <button>
        {tableHead}
        <span className='ms-1'>
          {tableHead && <i className="bi bi-caret-down"></i>}
        </span>
        {/* {tableHead !== "" ? <i className="bi bi-arrow-down-short text-lg mt-5"></i> : ""} */}
        </button>
    </th>
  )
}
