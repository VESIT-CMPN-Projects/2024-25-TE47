import React, { useEffect, useState } from "react";
import Chart from "react-apexcharts";
import ApexCharts from "apexcharts";

export const ChartComponent = ({ randomInt,id }) => {
    const [chartData, setChartData] = useState({
      series: [
        {
          name: "Sample Data",
          data: //[1,50,100,50,1]
            randomInt === 1
              ? [66.77, 62.96, 71.07, 69.09, 72.22, 62.6, 72.0]
              : [66.77, 72.96, 71.07, 69.09, 72.22, 65.6, 62.96],
        },
      ],
      options: {
        chart: {
          height: 50,
          width: 50,
          type: "line",
          zoom: {
            enabled: false,
          },
          toolbar: {
            show: false,
            autoSelected: 'zoom'
          },
          animations: {
            enabled: false,
          },
          margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          }, 
          padding: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
          }
        },
        dataLabels: {
          enabled: false,
        },
        stroke: {
          width: 1,
          curve: "straight",
          colors: [randomInt === 1 ? "#0ABB92" : "#d55438"],
        },
        xaxis: {
          labels: {
            show: false,
          },
          axisBorder: {
            show: false,
          },
          axisTicks: {
            show: false,
          },
          lines: {
            show: false,
          },
        },
        yaxis: {
          min: 62,
          max: 72,
          labels: {
            show: false,
          },
          axisBorder: {
            show: false,
          },
          axisTicks: {
            show: false,
          },
          lines: {
            show: false,
          },
        },
        grid: {
          show: false,
        },
        tooltip: {
          enabled: false,
        },
        markers: {
          hover: {
            sizeOffset: 0,
          },
        },
        title: {
          text: undefined,
        },
      },
    });

  // const getChartOptions = () => {
  //   return {
  //     series: [
  //       {
  //         name: "Sample Data",
  //         data:
  //           randomInt === 1
  //             ? [66.77, 62.96, 71.07, 69.09, 72.22, 65.6, 99.0]
  //             : [66.77, 72.96, 72.07, 69.09, 72.22, 65.6, 62.96],
  //       },
  //     ],
  //     chart: {
  //       height: 50,
  //       width: 50,
  //       type: "line",
  //       zoom: {
  //         enabled: false,
  //       },
  //       toolbar: {
  //         show: false,
  //       },
  //       animations: {
  //         enabled: false,
  //       },
  //     },
  //     dataLabels: {
  //       enabled: false,
  //     },
  //     stroke: {
  //       width: 1,
  //       curve: "smooth",
  //       colors: [randomInt === 1 ? "#0ABB92" : "#d55438"],
  //     },
  //     xaxis: {
  //       labels: {
  //         show: false,
  //       },
  //       axisBorder: {
  //         show: false,
  //       },
  //       axisTicks: {
  //         show: false,
  //       },
  //       lines: {
  //         show: false,
  //       },
  //     },
  //     yaxis: {
  //       min: 62.96,
  //       max: 72.0,
  //       labels: {
  //         show: false,
  //       },
  //       axisBorder: {
  //         show: false,
  //       },
  //       axisTicks: {
  //         show: false,
  //       },
  //       lines: {
  //         show: false,
  //       },
  //     },
  //     grid: {
  //       show: false,
  //     },
  //     tooltip: {
  //       enabled: false,
  //     },
  //     markers: {
  //       hover: {
  //         sizeOffset: 0,
  //       },
  //     },
  //     title: {
  //       text: undefined,
  //     },
  //   };
  // };

  // useEffect(() => {
  //   if (document.getElementById({id}) && typeof ApexCharts !== "undefined") {
  //     const chart = new ApexCharts(
  //       document.getElementById({id}),
  //       getChartOptions()
  //     );
  //     chart.render();
  //   }
  // });

  return (
    <div id={id} className="p-0 h-fit">
      <Chart
        options={chartData.options}
        series={chartData.series}
        type="line"
        width={"40%"}
      />
    </div>
  );
};
