import React from "react";
import { InvestmentInfoHeader } from "./InvestmentInfoHeader";
import { ActualTableHeader } from "./ActualTableHeader";
import { HoldingRow } from "./HoldingRow";

export const InvestmentTable = () => {
  const tableHeads = ["COMPANY","","MKT PRICE","RETURNS(%)","CURRENT"];
  const holdingsList = ["Bank Of Maharashtra","NALCO","Tata Steel","SAIL","Union Bank Of India","KCP Sugar","Bajaj Hindustan Sugar","IDFC First Bank","NHPC","IRB Infra Devs"];
  return (
    <div className="border border-borderColor rounded-lg">
      <InvestmentInfoHeader />
      <table className="w-full p-1">
        <thead className="p-5 text-sm font-normal">
        {tableHeads.map(tableHead => <ActualTableHeader tableHead={tableHead} />)}
        </thead>
      <tbody className="p-5 text-sm font-normal rounded-xl">
        {holdingsList.map((stockName,i) => <HoldingRow stockName={stockName} i={i} />)}
      </tbody>
      </table>
    </div>
  );
};
