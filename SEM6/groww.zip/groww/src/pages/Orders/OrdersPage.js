import React, { useEffect } from 'react';
import { useFetch } from "../../hooks/useFetch";
import { OrderFilterSection } from './components/OrderFilterSection';
import { OrdersDetailSection } from './components/OrdersDetailSection';
import { getLoggedInUserDetails } from '../../services/authService';
import { useDispatch } from 'react-redux';
import { setOrders } from '../../store/ordersSlice';

export const OrdersPage = () => {
  const dispatch = useDispatch();
  const { data, setUrl } = useFetch(() => dispatch(
    setOrders({ orders: data })
  ));

  useEffect(() => {
    async function getUserDataAndFetchOrders() {
      const user = await getLoggedInUserDetails();
      setUrl(`${process.env.REACT_APP_API_URL}/orders?user_id=${user.id}`);
    }
    getUserDataAndFetchOrders();
  }, [])
  return (
    <div className="bg-black min-h-screen flex py-8 px-40">
      <div className="flex w-full">
        <div className="w-96">
          <OrderFilterSection />
        </div>
        <div className="flex-1 overflow-y-auto ml-8">
          {data && <OrdersDetailSection data={data} />}
        </div>
      </div>
    </div>
  );
};
