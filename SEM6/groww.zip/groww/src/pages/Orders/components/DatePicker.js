import React, { useState, useRef, useEffect } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

export const DatePicker = ({ initialValue }) => {
  const [date, setDate] = useState(null);
  const [showCalendar, setShowCalendar] = useState(false);
  const inputRef = useRef(null);

  const handleDateChange = (selectedDate) => {
    setDate(selectedDate);
    setShowCalendar(false);
  };

  const handleClickOutside = (e) => {
    if (inputRef.current && !inputRef.current.contains(e.target)) {
      setShowCalendar(false);
    }
  };
  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  return (
    <div className="relative">
      <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
      <svg
          className="w-4 h-4 text-gray-500 dark:text-gray-400 cursor-pointer"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="#099F78"
          viewBox="0 0 20 20"
        >
          <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
        </svg>
      </div>
      <input
        ref={inputRef}
        type="text"
        className="h-10 block w-full p-4 ps-10 text-sm text-white border border-stone-600 rounded-lg bg-transparent"
        placeholder={initialValue}
        value={date ? date.toLocaleDateString() : ""}
        onClick={() => setShowCalendar(!showCalendar)}
        readOnly
      />
      {showCalendar && (
        <div className="absolute z-10 bg-white border border-gray-300 p-4 rounded-lg shadow-md">
          <Calendar onChange={handleDateChange} value={date || new Date()} />
        </div>
      )}
    </div>
  );
};