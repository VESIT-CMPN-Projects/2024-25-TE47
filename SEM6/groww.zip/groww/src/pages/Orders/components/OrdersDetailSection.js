import React from 'react';
import { OrderDetailCard } from './OrderDetailCard';

export const OrdersDetailSection = ({ data }) => {
  return (
    <div className="space-y-4 scroll-smooth">
      {data && data.map(order => <OrderDetailCard order={order} key={order.id} />)}
    </div>
  );
};
