import React from 'react';

export const OrderDetailCard = ({ order }) => {
  const orderDate = new Date(order.orderTime);
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return (
    <div className="text-white divide-y divide-dashed divide-stone-600">
      <header className="text-stone-500 text-left">
        <p className="font-bold mb-4">{orderDate.getDay()} {months[orderDate.getMonth()]} {orderDate.getFullYear()}</p>
      </header>
      {order && console.log(order)}
      <section className="flex flex-row  justify-between space-x-32 py-4">
        <div>
          <p>{order.stockDetail.name}</p>
          <p >Buy - {order.orderPrice}</p>
        </div>
        <div>
          <p>{order.orderValue / order.averagePrice}</p>
          <p className='text-stone-400'>Qty</p>
        </div>
        <div>
          <p>${order.averagePrice}</p>
          <p className='text-stone-400'>Avg price</p>
        </div>
        <div className="flex items-center">
          <span>{orderDate.getHours()}:{orderDate.getMinutes()} {orderDate.getHours() > 12 ? 'PM' : 'AM'}</span>
          <span className="ml-2 w-3 h-3 bg-primary-600 rounded-full"></span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 320 512"
            width="12"
            height="12"
            className="ml-2 cursor-pointer"
          >
            <path
              fill="#57534e"
              d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"
            />
          </svg>
        </div>
      </section>
    </div>
  );
};
