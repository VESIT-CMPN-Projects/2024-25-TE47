import React from 'react'
import { DatePicker } from './DatePicker'

export const OrderFilterSection = () => {
  return (
    <div className="text-white border rounded border-borderColor w-96 divide-y divide-solid divide-stone-600 fixed">
      <div className="flex justify-between items-start p-5">
        <div className='font-semibold'>Filters</div>
        <div className='font-semibold text-primary-500 cursor-pointer'>Clear all</div>
      </div>
      <div className='p-5'>
        <div className="flex items-center mb-2">
          <input
            id="equity"
            type="radio"
            name="equity"
            style={{ accentColor: "#0ABB92" }}
            className="w-4 h-4 border border-gray-300 bg-gray-50"
            required
          />
          <label
            htmlFor="option1"
            className="ms-2 text-gray-900 dark:text-gray-300"
          >
            Equity
          </label>
        </div>
        <div className="flex items-center mb-3">
          <input
            id="gtt-Equity"
            type="radio"
            name="equity"
            style={{ accentColor: "#0ABB92" }}
            className="w-4 h-4 border border-gray-300 bg-gray-50"
            required
          />
          <label
            htmlFor="option1"
            className="ms-2 text-gray-900 dark:text-gray-300"
          >
            GTT - Equity
          </label>
        </div>
        <div> 
            <label htmlFor="default-search" className="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
            <div className="relative">
                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                    <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                    </svg>
                </div>
                <input type="search" id="default-search" className="h-10 block w-full p-4 ps-10 text-sm text-white border border-stone-600 rounded-lg bg-transparent" placeholder="Search for a Stock" required />
            </div>
        </div>
      </div>
      <div className='flex space-x-2 p-5 text-black'>
        <DatePicker initialValue="From"/>
        <DatePicker initialValue="To"/>
      </div>
      <div className='p-5'>
        <div className="flex items-start mb-5">
          <div className="flex items-center h-5">
            <input
              id="buyOrders"
              type="checkbox"
              style={{ accentColor: "#0ABB92" }}
              className="w-4 h-4 border border-gray-300 rounded bg-gray-50"
              required
            />
          </div>
          <label
            htmlFor="buyOrders"
            className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
          >
            Buy orders
          </label>
        </div>
        <div className="flex items-start">
          <div className="flex items-center h-5">
            <input
              id="sellOrders"
              type="checkbox"
              style={{ accentColor: "#0ABB92" }}
              className="w-4 h-4 border border-gray-300 rounded bg-gray-50"
              required
            />
          </div>
          <label
            htmlFor="sellOrders"
            className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
          >
            Sell orders
          </label>
        </div>
      </div>
      <div className='p-5'>
        <div className='flex justify-between'>
          <div className="flex items-start mb-5">
            <div className="flex items-center h-5">
              <input
                id="OrderInProgress"
                type="checkbox"
                style={{ accentColor: "#0ABB92" }}
                className="w-4 h-4 border border-gray-300 rounded bg-gray-50"
                required
              />
            </div>
            <label
              htmlFor="OrderInProgress"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              Orders in progress
            </label>
          </div>
          <span className="mt-1 w-3 h-3 bg-yellow-500 rounded-full"></span>
        </div>
        <div className='flex justify-between'>
          <div className="flex items-start mb-5">
            <div className="flex items-center h-5">
              <input
                id="successfullOrders"
                type="checkbox"
                style={{ accentColor: "#0ABB92" }}
                className="w-4 h-4 border border-gray-300 rounded bg-gray-50"
                required
              />
            </div>
            <label
              htmlFor="successfullOrders"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              Successfull orders
            </label>
          </div>
          <span className="mt-1 w-3 h-3 bg-primary-500 rounded-full"></span>
        </div>
        <div className='flex justify-between'>
          <div className="flex items-start">
            <div className="flex items-center h-5">
              <input
                id="unsuccessFullOrders"
                type="checkbox"
                style={{ accentColor: "#0ABB92" }}
                className="w-4 h-4 border border-gray-300 rounded bg-gray-50"
                required
              />
            </div>
            <label
              htmlFor="unsuccessFullOrders"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              Unsuccessfull orders
            </label>
          </div>
          <span className="mt-1 w-3 h-3 bg-danger rounded-full"></span>
        </div>
      </div>
    </div>
  )
}
