export { Login } from "./Auth/Login";
export { Register } from "./Auth/Register";
export { HomePage } from "./Home/HomePage";
export { Wallet } from "./Wallet/Wallet";
export { Investments } from "./Investments/Investments";
export { StockDetailsPage } from "./StockDetail/StockDetailsPage";
export { SipCalculator } from "./SipCalculator/SipCalculator";
export { OrdersPage } from "./Orders/OrdersPage";