import React from "react";

export const Withdraw = ({balance}) => {
  return (
    <div>
      <div className="flex mb-6 justify-between text-sm">
        <div>Withdrawable</div>
        <div>${balance}</div>
      </div>
      <div className="w-full mb-6 pb-2 flex border-b-2 border-borderColor justify-between">
        <div>
          <p className="text-sm rounded-l-md font-medium">Enter Amount:</p>
        </div>
        <div className="w-[30%] flex text-primary-500">
          <div className="h-6 px-1 bg-backgroundInputColor">$</div>
          <input
            type="text"
            className="w-full h-6 bg-backgroundInputColor focus:outline-none text-sm p-2 text-right"
            defaultValue={100}
          />
        </div>
      </div>
      <div>
        To: HDFC Bank Acc No: xxxxxx2103
      </div>
    </div>
  );
};
