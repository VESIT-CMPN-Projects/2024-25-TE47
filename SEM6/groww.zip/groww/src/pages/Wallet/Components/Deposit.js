import React from 'react'

export const Deposit = ({inputRef}) => {
  return (
    <div className='flex my-2 justify-between'>
        <div>
            <p className='text-sm font-medium'>Enter Amount:</p>
        </div>
        <div className='w-[30%] flex text-primary-500'>
            <div className='h-6 px-1 bg-backgroundInputColor'>$</div>
            <input ref={inputRef} type="text" className='w-full h-6 bg-backgroundInputColor focus:outline-none text-sm p-2 text-right' defaultValue={100}/>
        </div>
    </div>
  )
}
