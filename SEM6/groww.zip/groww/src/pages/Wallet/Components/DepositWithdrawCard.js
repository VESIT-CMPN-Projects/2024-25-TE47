import React, { useRef, useState } from "react";
import { Deposit } from "./Deposit";
import { Withdraw } from "./Withdraw";
import { DepositWithdrawTabs } from "./DepositWithdrawTabs";
import { motion } from "framer-motion";
import { useDispatch, useSelector } from "react-redux";
import { setUserPortfolio } from "../../../store/portfolioSlice";
import { updatePortfolio } from "../../../services/updatePortfolioService";

export const DepositWithdrawCard = () => {
  const [depositOrWithdraw, setDepositOrWithdraw] = useState("deposit");
  const { balance } = useSelector(state => state.portfolio.userPortfolio);
  const inputRef = useRef(100);
  const portfolio = useSelector(state => state.portfolio.userPortfolio);
  const dispatch = useDispatch();

  const handleButtonClick = async () => {
    const value = parseInt(inputRef.current.value);
    if(depositOrWithdraw === 'deposit') {
      const balanceAddPortfolio = {
        ...portfolio,
        balance: portfolio.balance + value,
      }
      dispatch(setUserPortfolio({userPortfolio: balanceAddPortfolio}));
      await updatePortfolio(balanceAddPortfolio);
    } else {

    }
  }
  return (
    <div className="border border-borderColor rounded-lg">
      <div>
        <DepositWithdrawTabs
          depositOrWithdraw={depositOrWithdraw}
          setDepositOrWithdraw={setDepositOrWithdraw}
        />
      </div>
      <div className="p-3">
        {depositOrWithdraw === "deposit" ? <Deposit inputRef={inputRef} /> : <Withdraw balance={balance} />}
      </div>
      <div className="mt-10 p-3">
        <motion.button className="rounded-lg w-full p-2 text-sm font-bold bg-primary-500"
        onClick={handleButtonClick}
        whileTap={{scale: 0.95}}
        whileHover={{ scale: 1.02}}>
          {depositOrWithdraw === "deposit" ? "DEPOSIT MONEY" : "WITHDRAW MONEY"}
        </motion.button>
      </div>
    </div>
  );
};
