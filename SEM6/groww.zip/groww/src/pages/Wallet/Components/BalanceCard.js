import React from "react";
import { useSelector } from "react-redux";

export const BalanceCard = () => {
  const { balance } = useSelector(state => state.portfolio.userPortfolio);
  return (
    <div className="border border-borderColor rounded-xl">
      <div className="flex border-b-[1px] border-borderColor justify-between py-6 px-6">
        <div>
          <p className="mb-3">For Stocks</p>
          <p className="text-3xl font-bold">${balance}</p>
        </div>
        <div className="my-auto">
          <p className="text-xl"><i className="bi bi-info-circle cursor-pointer"></i></p>
        </div>
      </div>
      <div className="py-4 px-6 border-b-[1px] border-borderColor text-lg font-semibold flex justify-between">
        <div className="">
          Used Balance
        </div>
        <div>
          $0.00
        </div>
      </div>
      <div className="py-4 px-6 text-lg font-semibold flex justify-between">
        <div>
          All Transactions
        </div>
        <div className="cursor-pointer">
        <i className="bi bi-chevron-right"></i>
        </div>
      </div>
    </div>
  );
};
