import React from 'react'
import { BalanceCard } from './Components/BalanceCard'
import { DepositWithdrawCard } from './Components/DepositWithdrawCard'
import { useSelector } from 'react-redux';

export const Wallet = () => {
  const userPortfolio = useSelector(state => state.portfolio.userPortfolio);
   
  return (
    <main className='my-10 flex gap-8'>
        <div className="w-full">
          { userPortfolio && <BalanceCard />}
        </div>
        <div className='w-[38%] md:block hidden'>
          { userPortfolio && <DepositWithdrawCard balance={userPortfolio?.balance} />}
        </div>
    </main>
  )
}
