import React from 'react'
import { Calculator } from './components/Calculator'

export const SipCalculator = () => {
  return (
    <main>
        <h2 className='font-semibold mb-6 text-3xl'>SIP Calculator</h2>
        <Calculator />
    </main>
  )
}
