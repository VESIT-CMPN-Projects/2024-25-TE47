import React, { useEffect, useState } from "react";
import { Donut } from "./Donut";

export const Calculator = () => {
  const [monthlyInvestment, setMonthlyInvestment] = useState(25000);
  const [interestRate, setInterestRate] = useState(12.0);
  const [timePeriod, setTimePeriod] = useState(10);
  const [estimateReturn, setEstimateReturn] = useState(2808477);
  const [investmentValue, setInvestmentValue] = useState(3000000);
  const handleMonthlyInvestmentChange = (e) => {
    setMonthlyInvestment(e.target.value);
  };
  const handleInterestRateChange = (e) => {
    setInterestRate(e.target.value);
  };
  const handleTimePeriodChange = (e) => {
    setTimePeriod(e.target.value);
  };
  useEffect(() => {
    let noOfPayments = 12 * timePeriod;
    setInvestmentValue(monthlyInvestment * noOfPayments);
    let monthlyRateOfReturn = interestRate / 12 / 100;
    setEstimateReturn(
      monthlyInvestment *
        ((Math.pow(1 + monthlyRateOfReturn, noOfPayments) - 1) /
          monthlyRateOfReturn) *
        (1 + monthlyRateOfReturn) -
        investmentValue
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monthlyInvestment, interestRate, timePeriod]);
  return (
    <div className="py-16 px-12 flex rounded-2xl border border-borderColor">
      <div className="w-[50%] p-3 my-auto">
        <div className="mb-12">
          <div className="flex mb-6 justify-between">
            <p className="text-xl my-auto">Monthly Investment</p>
            <div className="w-[25%] bg-backgroundInputColor rounded my-auto flex text-primary-500">
              <div className="h-full rounded px-2 text-2xl bg-backgroundInputColor">
                $
              </div>
              <input
                type="text"
                className="w-full bg-backgroundInputColor rounded focus:outline-none font-semibold text-xl p-1 text-right"
                value={monthlyInvestment}
                onChange={handleMonthlyInvestmentChange}
              />
            </div>
          </div>
          <div className="w-full rounded flex bg-borderColor h-1">
            <input
              id="steps-range"
              type="range"
              min="500"
              max="1000000"
              value={monthlyInvestment}
              step="500"
              style={{
                background: `linear-gradient(to right, #33BA98 ${
                  monthlyInvestment / 10000
                }%, #2e2e2e ${monthlyInvestment / 10000}%)`,
              }}
              className="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-borderColor"
              onChange={handleMonthlyInvestmentChange}
            />
          </div>
        </div>
        <div className="mb-12">
          <div className="flex mb-6 justify-between">
            <p className="text-xl my-auto">Expected Return Rate (%)</p>
            <div className="w-[25%] bg-backgroundInputColor rounded my-auto flex text-primary-500">
              <input
                type="text"
                className="w-full font-semibold bg-backgroundInputColor rounded focus:outline-none text-xl p-1 pe-0 text-right"
                value={interestRate}
                onChange={handleInterestRateChange}
              />
              <p className="my-auto pe-1 text-xl">%</p>
            </div>
          </div>
          <div className="w-full flex rounded bg-borderColor h-1">
            <input
              id="steps-range"
              type="range"
              min="1.0"
              max="30.0"
              value={interestRate}
              step="0.1"
              style={{
                background: `linear-gradient(to right, #33BA98 ${
                  (interestRate / 30) * 100
                }%, #2e2e2e ${(interestRate / 30) * 100}%)`,
              }}
              className="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-borderColor"
              onChange={handleInterestRateChange}
            />
          </div>
        </div>
        <div className="mb-12">
          <div className="flex mb-6 justify-between">
            <p className="text-xl my-auto">Time Period</p>
            <div className="w-[25%] bg-backgroundInputColor rounded my-auto flex text-primary-500">
              <input
                type="text"
                className="w-full font-semibold bg-backgroundInputColor rounded focus:outline-none text-xl p-1 pe-0 text-right"
                value={timePeriod}
                onChange={handleTimePeriodChange}
              />
              <p className="my-auto px-1 text-xl"> Yr</p>
            </div>
          </div>
          <div className="w-full rounded flex bg-borderColor h-1">
            <input
              id="steps-range"
              type="range"
              min="1"
              max="40"
              value={timePeriod}
              step="1"
              style={{
                background: `linear-gradient(to right, #33BA98 ${
                  (timePeriod / 40) * 100
                }%, #2e2e2e ${(timePeriod / 40) * 100}%)`,
              }}
              className="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-borderColor"
              onChange={handleTimePeriodChange}
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between mb-3">
            <p>Invested Value</p>
            <p className="font-bold">
              ${investmentValue.toLocaleString("en-IN")}
            </p>
          </div>
          <div className="flex justify-between mb-3">
            <p>Expected Return</p>
            <p className="font-bold">
              ${Math.round(estimateReturn).toLocaleString("en-IN")}
            </p>
          </div>
          <div className="flex justify-between">
            <p>Total Value</p>
            <p className="font-bold">
              $
              {(investmentValue + Math.round(estimateReturn)).toLocaleString(
                "en-IN"
              )}
            </p>
          </div>
        </div>
      </div>

      <div className="w-[50%] p-3">
        <div className="mb-12">
          <div className="flex justify-evenly">
            <div className="flex">
              <span className="bg-purple-100 my-auto inline-block me-1 w-[20px] h-[9px] rounded-full"></span>
              <p>Invested Amount</p>
            </div>
            <div className="flex">
              <span className="bg-purple-500 my-auto inline-block me-1 w-[20px] h-[9px] rounded-full"></span>
              <p>Estimate Return</p>
            </div>
          </div>
          <Donut
            investmentValue={investmentValue}
            estimateReturn={estimateReturn}
          />
        </div>
        <div className="w-full">
          <button className="p-2 rounded-lg font-semibold ms-[40%] mx-auto bg-primary-500 text-white hover:opacity-80">
            INVEST NOW
          </button>
        </div>
      </div>
    </div>
  );
};
