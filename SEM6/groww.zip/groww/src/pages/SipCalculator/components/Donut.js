import React from "react";
import ReactApexChart from "react-apexcharts";

export const Donut = ({investmentValue,estimateReturn}) => {
  const options = {
    chart: {
      type: 'donut',
      background: '#121212', // dark background
    },
    stroke: {
        width: 0
    },
    colors: ['#181a2a', '#98a4ff'],
    plotOptions: {
      pie: {
        donut: {
          size: '65%', // Adjust the thickness of the donut
        },
      },
    },
    dataLabels: {
      enabled: false,
    },
    tooltip: {
      enabled: false, 
    },
    legend: false,
    states: {
        hover: {
            filter: {
                type: 'none'
            }
        }
    }
  };

  const series = [investmentValue, estimateReturn];

  return (
    <div className="donut-chart" style={{ padding: '20px', backgroundColor: '#121212' }}>
      <ReactApexChart options={options} series={series} type="donut" height={300} />
    </div>
  );
};

