export const CONSTANT_1D = "1D";
export const CONSTANT_1M = "1M";
export const CONSTANT_6M = "6M";
export const CONSTANT_1Y = "1Y";
export const CONSTANT_2Y = "2Y";
export const CONSTANT_ALL = "ALL";


export const MINUTE = 'minute';
export const HOUR = 'hour';
export const DAY = 'day';
export const WEEK = 'week';
export const MONTH = 'month';
export const QUARTER = 'quarter';