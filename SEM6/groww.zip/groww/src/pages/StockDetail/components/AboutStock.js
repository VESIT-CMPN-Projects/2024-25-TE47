import React from "react";

export const AboutStock = ({
    randomInt,
    tickerData,
    currentPrice,
    previousPrice,
    duration,
    setIsWatchlistModalVisible,
}) => {
    const profitOrLoss = currentPrice - previousPrice > 0 ? "profit" : "loss";
    return (
        <div className="w-full">
            <div className="flex justify-between">
                <div>
                    <img
                        src={`${tickerData?.branding?.logo_url}?apiKey=${process.env.REACT_APP_STOCK_API_KEY}`}
                        alt=""
                        className="bg-slate-50 w-8 h-8x p-1 mb-4"
                    />
                    <p className="text-2xl font-semibold mb-1">
                        {tickerData?.name}
                    </p>
                    <div className="flex gap-x-1">
                        <p className="text-xl font-semibold me-2">
                            ${currentPrice.toFixed(2)}
                        </p>
                        <p
                            className={`my-auto ${
                                profitOrLoss === "profit"
                                    ? "text-primary-500"
                                    : "text-danger"
                            }`}
                        >
                            {profitOrLoss === "profit" ? "+" : "-"}
                            {(profitOrLoss === "profit"
                                ? currentPrice - previousPrice
                                : previousPrice - currentPrice
                            ).toFixed(2)}
                            $ (
                            {(
                                (Math.abs(currentPrice - previousPrice) /
                                    currentPrice) *
                                100
                            ).toFixed(2)}
                            %)
                        </p>
                        <p className="my-auto"> {duration}</p>
                    </div>
                </div>
                <div className="flex gap-x-3">
                    <button className="border border-borderColor h-fit my-auto p-2 text-sm font-semibold rounded-lg">
                        <i className="bi bi-alarm me-1"></i>
                        Create Alert
                    </button>
                    <button
                        className="border border-borderColor h-fit my-auto p-2 text-sm font-semibold rounded-lg"
                        onClick={() => setIsWatchlistModalVisible(true)}
                    >
                        <i className="bi bi-bookmark me-1"></i>
                        Watchlist
                    </button>
                </div>
            </div>
        </div>
    );
};
