import React from "react";

export const Performance = ({ dayHighLowArray/*, yearHighLowArray */}) => {
    const sortedDayArray = dayHighLowArray.sort(function (a, b) {
        return b.c - a.c;
    });
    const sortedYearArray = dayHighLowArray.sort(function (a, b) {
        return b.c - a.c;
    });
    const dayHighLowPercentage = (dayHighLowArray[0]?.c / sortedDayArray[0]?.c + (sortedDayArray[sortedDayArray.length-1] - sortedDayArray[0]?.c)) * 100;
    return (
        <>
            <h2 className="mb-6 text-xl font-bold">
                Performance <i className="bi bi-info-circle-fill"></i>
            </h2>
            <div className="flex font-semibold mb-4 justify-between">
                <div className="">
                    <p className="mb-2">Today's Low</p>
                    {(sortedDayArray[sortedDayArray.length - 1]?.c).toFixed(2)}
                </div>
                <div className="w-[70%] my-auto">
                    <div className={`w-full ms-[${dayHighLowPercentage}%]`}>
                        <i
                            className={`bi bi-caret-down-fill w-full ms-[${dayHighLowPercentage}%]`}
                        ></i>
                    </div>
                    <div className="w-full my-auto bg-primary-500 rounded-full h-1.5"></div>
                </div>
                <div className="text-right">
                    <p className="mb-2">Today's High</p>
                    {(sortedDayArray[0]?.c).toFixed(2)}
                </div>
            </div>
            <div className="flex mb-4 justify-between">
                <div className="me-2">
                    <p className="mb-2">52W Low</p>
                    {(sortedYearArray[sortedYearArray.length - 1]?.c).toFixed(
                        2
                    )}
                </div>
                <div className="w-[70%] my-auto me-2">
                    <div className={`w-full ms-[10px]`}>
                        <i
                            className={`bi bi-caret-down-fill w-full ms-[400px]`}
                        ></i>
                    </div>
                    <div className="w-full my-auto bg-primary-500 rounded-full h-1.5"></div>
                </div>
                <div className="text-right">
                    <p className="mb-2">52W High</p>
                    {(sortedYearArray[0]?.c).toFixed(2)}
                </div>
            </div>
        </>
    );
};
