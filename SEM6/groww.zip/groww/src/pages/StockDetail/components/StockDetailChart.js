import React, { useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart,
  LinearScale,
  LineElement,
  PointElement,
  CategoryScale,
  Tooltip,
} from "chart.js";
// import { FinancialChart } from "chartjs-chart-financial";
import {
  CONSTANT_1D,
  CONSTANT_1M,
  CONSTANT_1Y,
  CONSTANT_2Y,
  CONSTANT_6M,
  CONSTANT_ALL,
  DAY,
  HOUR,
  MINUTE,
  WEEK,
} from "../../constants/chartConstants";
import CandleStick from "../../../assets/CandleStick.svg";
import LineSvg from "../../../assets/LineSvg.svg";

Chart.register(CategoryScale, LinearScale, LineElement, PointElement,Tooltip); //FinancialChart

export const StockDetailChart = ({
  chartData,
  duration,
  setDuration,
  setFromDate,
  toDate,
  setTimespan,
  setMultiplier
}) => {
  const [candleChart,setCandleChart] = useState(false);

  const prices = [];
  chartData &&
    chartData.forEach((data) => {
      prices.push(data.c);
    });

  const durationChange = CONSTANT => {
    let revisedDate;
    switch(CONSTANT) {
      case CONSTANT_1D:
        if(!(duration === CONSTANT_1D)) {
          setDuration(CONSTANT_1D);
          revisedDate = new Date(new Date(toDate) - (86400000)); 
          setTimespan(MINUTE); 
          setMultiplier(1);
        }
        break;
      case CONSTANT_1M:
        if(!(duration === CONSTANT_1M)) {
          setDuration(CONSTANT_1M);
          revisedDate = new Date(new Date(toDate) - (86400000 * 30));
          setTimespan(MINUTE); 
          setMultiplier(15); 
        }
        break;
      case CONSTANT_6M:
        if(!(duration === CONSTANT_6M)) {
          setDuration(CONSTANT_6M);
          revisedDate = new Date(new Date(toDate) - (86400000 * 30 * 6));
          setTimespan(MINUTE); 
          setMultiplier(30); 
        }
        break;
      case CONSTANT_1Y:
        if(!(duration === CONSTANT_1Y)) {
          setDuration(CONSTANT_1Y);
          revisedDate = new Date(new Date(toDate) - (86400000 * 30 * 12));
          setTimespan(DAY); 
          setMultiplier(1); 
        }
        break;
      case CONSTANT_2Y:
        if(!(duration === CONSTANT_2Y)) {
          setDuration(CONSTANT_2Y);
          revisedDate = new Date(new Date(toDate) - (86400000 * 30 * 24));
          setTimespan(WEEK); 
          setMultiplier(1); 
        }
        break;
      case CONSTANT_ALL:
        if(!(duration === CONSTANT_ALL)) {
          setDuration(CONSTANT_ALL);
          revisedDate = new Date(new Date(toDate) - (86400000 * 30 * 24));
          setTimespan(WEEK);
          setMultiplier(1); 
        }
        break;
      default:
        break;
    }
    setFromDate(`${revisedDate.getFullYear()}-${revisedDate.getMonth()+1 < 10 ? '0'.concat(revisedDate.getMonth() + 1) : revisedDate.getMonth() + 1}-${revisedDate.getDate()+1 < 10 ? '0'.concat(revisedDate.getDate() + 1) : revisedDate.getDate() + 1}`);
  }

  const renderLineChart = () => {
    return (
      <>
        <Line
          style={{ height: "20rem" }}
          data={{
            labels: prices,
            datasets: [
              {
                data: prices,
                label: "Share Price",
                borderColor: prices[0] < prices[prices.length-1] ? "rgba(10,187,146,1)" : "rgba(213,84,56)",
                borderWidth: 2,
                pointRadius: 0.1,
                tension: 0.4,
              },
            ],
          }}
          options={{
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false,
              },
              tooltip: {
                enabled: true,
                intersect: "nearest",
                callbacks: {
                  label: function (context) {
                    const label = context.dataset.label || "";
                    const value = context.raw;
                    return `${label}: ${value}`;
                  },
                },
              },
            },
            scales: {
              x: {
                grid: {
                  display: false,
                },
                ticks: {
                  display: false,
                },
              },
              y: {
                grid: {
                  display: false,
                },
                ticks: {
                  display: false,
                },
              },
            },
          }}
        />
      </>
    );
  };

  const renderCandleStickChart = () => {
    return (
      <>
        <Chart type="candlestick" style={{ height: "20rem" }}
          data={{
            datasets: [
              {
                label: "Candlestick Data",
                // data: candlestickData,
                borderColor: "rgba(10,187,146,1)",
                color: {
                  up: "#10BB92", // Green for upward movement
                  down: "#FF6384", // Red for downward movement
                  unchanged: "#999999", // Gray for unchanged prices
                },
              },
            ],
          }}
        />
      </>
    )
  }

  const activePillClassList =
    "rounded-2xl px-4 text-xs py-2 border border-white bg-white bg-opacity-10 hover:cursor-pointer";

  const inactivePillClassList =
    "rounded-2xl px-4 text-xs py-2 border border-borderColor hover:cursor-pointer";

  return (
    <div className="my-8">
      <div>{chartData && candleChart ? renderCandleStickChart() : renderLineChart()}</div>
      <div className="flex gap-x-2 justify-center">
        <button
          className={
            duration === CONSTANT_1D
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => durationChange(CONSTANT_1D)}
        >
          1D
        </button>
        <button
          className={
            duration === CONSTANT_1M
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => durationChange(CONSTANT_1M)}
        >
          1M
        </button>
        <button
          className={
            duration === CONSTANT_6M
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => durationChange(CONSTANT_6M)}
        >
          6M
        </button>
        <button
          className={
            duration === CONSTANT_1Y
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => durationChange(CONSTANT_1Y)}
        >
          1Y
        </button>
        <button
          className={
            duration === CONSTANT_2Y
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => durationChange(CONSTANT_2Y)}
        >
          2Y
        </button>
        <button
          className={
            duration === CONSTANT_ALL
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => durationChange(CONSTANT_ALL)}
        >
          All
        </button>
        <button
          className={
            duration === CONSTANT_ALL
              ? activePillClassList
              : inactivePillClassList
          }
          onClick={() => setCandleChart(!candleChart)}
        >
          <img src={candleChart ? LineSvg : CandleStick} alt="" />
        </button>
      </div>
    </div>
  );
};
