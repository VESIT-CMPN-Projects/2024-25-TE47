import React from "react";

export const BoughtShares = ({
    randomInt,
}) => {
    const noOfShares = Math.round(Math.random() * 100 + 1);
    const avgPriceOfShare = parseInt((Math.random() * 1000 + 10).toFixed(2));
    const plPerc = parseFloat((Math.random() * 10).toFixed(2));
    const amountInvested = noOfShares * avgPriceOfShare;
    const plAmount = Math.round((amountInvested * plPerc) / 100);
    return (
        <div className="flex mb-6 justify-between p-5 border border-borderColor rounded-xl">
            <div>
                <p className="text-xl">{noOfShares} Shares</p>
                <p>Avg Price ${avgPriceOfShare.toLocaleString("en-IN")}</p>
            </div>
            <div className="my-auto flex text-right">
                <div>
                    <p className="font-bold text-xl">
                        $
                        {(randomInt === 1
                            ? amountInvested + plAmount
                            : amountInvested - plAmount
                        ).toLocaleString("en-IN")}
                    </p>
                    <p
                        className={`${
                            randomInt === 1 ? "text-primary-500" : "text-danger"
                        }`}
                    >
                        <span className="me-1">
                            {randomInt === 1 ? "+" : "-"}${plAmount}
                        </span>
                        ({plPerc}%)
                    </p>
                </div>
                <button className="ps-4 text-2xl">
                    <i className="bi bi-caret-right"></i>
                </button>
            </div>
        </div>
    );
};
