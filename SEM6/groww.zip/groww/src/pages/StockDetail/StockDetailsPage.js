import React, { useEffect, useState } from "react";
import { AddStockToWatchListModal, BuySellCard } from "../../Components";
import { AboutStock } from "./components/AboutStock";
import { StockDetailChart } from "./components/StockDetailChart";
import { BoughtShares } from "./components/BoughtShares";
// import { Performance } from "./components/Performance";
import { useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setCurrentStock } from "../../store/currentStockSlice";
import { useFetch } from "../../hooks/useFetch";
import { CONSTANT_1D, DAY, MINUTE } from "../constants/chartConstants";

export const StockDetailsPage = () => {
  const randomInt = Math.floor(Math.random() * 2 + 1);
  const dispatch = useDispatch();
  const location = useLocation();
  const [duration,setDuration] = useState(CONSTANT_1D);
  const currentStockTicker = location.pathname.split("/")[2];
  const today = new Date(new Date() - 86400000);
  const [toDate,setToDate] = useState();
  const [fromDate,setFromDate] = useState();
  const [timespan,setTimespan] = useState(MINUTE);
  const [multiplier,setMultiplier] = useState(1);
  const [todaysPrices,setTodaysPrices] = useState(null);
  const [yearsPrices,setYearsPrices] = useState(null);
  const [isWatchlistModalVisible, setIsWatchlistModalVisible] = useState(false);
  
  const tickerDetailURL = `${process.env.REACT_APP_STOCK_API_BASE_URL}/v3/reference/tickers/${currentStockTicker}?apiKey=${process.env.REACT_APP_STOCK_API_KEY}`;
  
  const {
    data: tickerData
  } = useFetch(tickerDetailURL,() => {
    dispatch(
      setCurrentStock({
        currentStock: {
          stockName: currentStockTicker,
          averagePrice: 100,
        },
      })
    );
    setStartAndEndDate();
  });

  const {
    data: chartData,
    setUrl: chartDataURL,
  } = useFetch();

  const setYearsPricesHighLow = () => {
    const toDateStr = `${today.getFullYear()}-${today.getMonth()+1 < 10 ? '0'.concat(today.getMonth() + 1) : today.getMonth() + 1}-${today.getDate()}`;
    const oneYearAgoDate = new Date((today) - (86400000 * 30 * 12));
    const oneYearAgoDateStr = `${oneYearAgoDate.getFullYear()}-${oneYearAgoDate.getMonth()+1 < 10 ? '0'.concat(oneYearAgoDate.getMonth() + 1) : oneYearAgoDate.getMonth() + 1}-${oneYearAgoDate.getDate()}`;
    const barChartURL = `${process.env.REACT_APP_STOCK_API_BASE_URL}/v2/aggs/ticker/${currentStockTicker}/range/${multiplier}/${DAY}/${oneYearAgoDateStr}/${toDateStr}?adjusted=true&sort=asc&apiKey=${process.env.REACT_APP_STOCK_API_KEY}`;
    chartDataURL(barChartURL);
    setYearsPrices(chartData);
  }

  const setStartAndEndDate = async () => {
    if(today.getDay() > 0 && today.getDay() < 6) {
      const toDateStr = `${today.getFullYear()}-${today.getMonth()+1 < 10 ? '0'.concat(today.getMonth() + 1) : today.getMonth() + 1}-${today.getDate() < 10 ? '0'.concat(today.getDate()) : today.getDate()}`;
      setToDate(toDateStr);

      const previousDate = new Date(Date.now() - 86400000 * 2);
      const fromDateStr = `${previousDate.getFullYear()}-${previousDate.getMonth()+1 < 10 ? '0'.concat(previousDate.getMonth() + 1) : previousDate.getMonth() + 1}-${previousDate.getDate() < 10 ? '0'.concat(previousDate.getDate()) : previousDate.getDate()}`;
      setFromDate(fromDateStr);
    } else {
      let foundTradingDay = false;
      const currentDateEpoch = Date.now();
      let previousDate = new Date(currentDateEpoch - 86400000);
      let i = 1;
      while(!foundTradingDay) {
        previousDate = new Date(currentDateEpoch - (i++ * 86400000));
        if(previousDate.getDay() !== 0 && previousDate.getDay() !== 7) {
          foundTradingDay = true;
          const toDateStr = `${previousDate.getFullYear()}-${previousDate.getMonth()+1 < 10 ? '0'.concat(previousDate.getMonth() + 1) : previousDate.getMonth() + 1}-${previousDate.getDate()+1 < 10 ? '0'.concat(previousDate.getDate() + 1) : previousDate.getDate() + 1}`;

          previousDate = new Date(currentDateEpoch - (i++ * 86400000));
          const fromDateStr = `${previousDate.getFullYear()}-${previousDate.getMonth()+1 < 10 ? '0'.concat(previousDate.getMonth() + 1) : previousDate.getMonth() + 1}-${previousDate.getDate()+1 < 10 ? '0'.concat(previousDate.getDate() + 1) : previousDate.getDate() + 1}`;
          setFromDate(fromDateStr);
          setToDate(toDateStr);
        }
      }
    }
  }
  
  useEffect(() => {
    if(yearsPrices === null) {
      setYearsPricesHighLow();
    }
    const barChartURL = `${process.env.REACT_APP_STOCK_API_BASE_URL}/v2/aggs/ticker/${currentStockTicker}/range/${multiplier}/${timespan}/${fromDate}/${toDate}?adjusted=true&sort=asc&apiKey=${process.env.REACT_APP_STOCK_API_KEY}`;
    chartDataURL(barChartURL);
    if(todaysPrices === null)
      setTodaysPrices(chartData);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fromDate]);
  
  return (
    <main className="flex gap-x-6 my-4">
      <div className="w-[65%]">
        {/* <IndexSection /> */}
        
        {tickerData && chartData && (
          <AboutStock
            randomInt={randomInt}
            tickerData={tickerData?.results}
            currentPrice={chartData?.results[chartData?.results?.length - 1]?.c}
            previousPrice={chartData?.results[0].c}
            duration={duration}
            setIsWatchlistModalVisible={setIsWatchlistModalVisible}
          />
        )}
        {/*chartData &&*/ (
          <StockDetailChart
            randomInt={randomInt}
            chartData={chartData?.results}
            duration={duration}
            setDuration={setDuration}
            setFromDate={setFromDate}
            toDate={toDate}
            setTimespan={setTimespan}
            setMultiplier={setMultiplier}
          />
        )}
        <BoughtShares
          randomInt={randomInt}
        />
        
        {todaysPrices && console.log(todaysPrices)}
      </div>
      <div className="w-[35%]">
        {chartData && <BuySellCard stockData={tickerData?.results} currentStockPrice={chartData?.results[chartData?.results?.length - 1]?.c} />}
      </div>
      {isWatchlistModalVisible && <AddStockToWatchListModal tickerData={tickerData?.results} setIsWatchlistModalVisible={setIsWatchlistModalVisible} />}
    </main>
  );
};
